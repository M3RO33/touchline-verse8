# TOUCHLINE — Verse8 이식 준비

TOUCHLINE을 Vite·React 프로젝트로 옮긴 소스입니다. 게임 버전은 `SOURCE-PROVENANCE.json`의 `gameVersion`에 기록됩니다.

## 포함한 기능

Three.js 3D 경기장·선수·모션, 약 5분의 경기 흐름, 전후반 각각 0–30분 추가시간, 8개 VAR 장면, 5종 카메라, 리플레이·역재생·프레임 이동·접촉 확대·오프사이드 기준선, 재개 판정과 카드, 봉급 평가를 유지합니다. 5개 3D 무대, 평판 게이지와 레벨 해금, 단계별 100–40초 판정 제한, 핸드볼·홀딩·위험한 플레이·시뮬레이션 사례, 패스 경로와 압박 판단·결정적 물리를 포함합니다. Three.js는 npm 의존성입니다. 플랫폼 서버·계정·랭킹·결제 연동은 추가하지 않았습니다. 커리어 평판·레벨·해금·보유 자금·완료 경기 수는 브라우저 localStorage의 touchline.career.v1에 저장합니다.

## 첫 휘슬과 게임 HUD

v17의 시작 화면은 경기 시작, 튜토리얼, 설정을 표시합니다. 경기 시작을 누르면 무대를 선택할 수 있습니다. 튜토리얼에서는 동네 친선경기에서 세 가지 판정을 연습합니다. 첫 진입·수료 기록은 `touchline.first-whistle.v1`에, 정규 경기 기록은 `touchline.career.v1`에 저장합니다.

v17은 어두운 경기장과 방송형 점수판, VAR, 접을 수 있는 징계, 용어 수첩, 근거 장면 재생과 경기 보고서를 제공합니다. 공의 비행, 회전, 바운드 및 골대 충돌은 `ball-physics.mjs`가 계산합니다. UI 글꼴은 시스템 한국어 폰트를 사용합니다.

v22는 높은 공이 잔디에서 튄 뒤에도 전진해 굴러가도록 수정하고, 일반 경기에서 긴 패스가 첫 터치 전에 바운드하도록 개선합니다.

v21은 동작 확인에서 패스를 받은 뒤 공이 진행 방향으로 굴러가도록 수정하고, 태클과 낙상에서 고관절이 꺾이는 구간을 줄입니다.

v20은 낙상 중 발목과 상체·손을 보정하고, 공의 미끄러짐·회전·바운드 확인 메뉴를 추가합니다.

v19는 손가락·손목, 무릎·발목 자세와 동작의 전환을 보정하고 골키퍼 선방을 동작 확인에 추가합니다.

v18은 속도에 맞춘 디딤과 방향 전환, 드리블·퍼스트 터치·킥·태클의 동작을 보정합니다. pitch-audio.mjs는 접촉 시각의 타격음과 경기 시작·중단 휘슬을 생성합니다. 사용자의 경기 소리 설정을 유지합니다.

## 실행

Node.js 20.19+ 또는 22.12+를 사용하세요. `pnpm install`, `pnpm run dev`로 개발 서버를 엽니다. `pnpm run build`로 dist를 만들고 `pnpm run preview`로 확인할 수 있습니다. 테스트는 `pnpm test`입니다. `public/assets`의 인체 메시와 텍스처도 함께 가져오세요. 해당 버전의 모델·모션 출처와 이용 조건은 `licenses/ASSET-CREDITS.txt`와 `licenses/SHIPPED-SOURCES.txt`에서 확인할 수 있습니다.

## Verse8에서 적용

1. [Verse8 제작 화면](https://create.verse8.io/)에서 새 프로젝트를 만듭니다.
2. 함께 제공한 `IMPORT-PROMPT.ko.txt`와 이 패키지의 소스를 사용합니다. 첨부 ZIP을 실제로 풀어 읽을 수 있는지 먼저 확인하세요. ZIP 파일 복원을 보장하는 공식 문서는 확인하지 못했습니다. ZIP을 읽지 못하면 텍스트 소스와 `public/assets`의 바이너리 파일을 별도로 전달해야 합니다. 텍스트 파일만으로 모델 자산을 복원할 수 없습니다.
3. 소스의 `src`, `public/assets`, `index.html`, 라이선스를 프로젝트에 반영합니다. 기존 플랫폼 프로젝트의 package.json, Vite 설정, 환경변수·플랫폼 식별자를 먼저 확인하고 필요한 항목만 병합합니다. `three`는 0.180.0을 유지합니다. 이 로컬 패키지에는 플랫폼 인증정보·프로젝트 ID가 없습니다.
4. Preview에서 첫 휘슬의 도입 → 세 판정 → 재시도 → 수료 → 무대 선택, 기존 커리어 보존, 실제 3D 렌더링, 정규 경기, 기본/상세 VAR, 근거 재생, 추가시간, 전체 화면, 창 크기 변경, 소리를 확인합니다. iframe 정책과 저장소 정책은 플랫폼 안에서 별도로 확인해야 합니다.
5. 검증 후 편집기의 Launch로 공개합니다. 이 패키지 생성만으로 Verse8에 배포되지는 않습니다.

## 구조와 후속 편집

- `src/App.tsx`: 원본 HUD와 대화상자를 한 번 마운트합니다.
- `src/main.tsx`: DOM 마운트 후 게임을 시작합니다. 같은 시뮬레이션을 두 번 초기화하지 마세요.
- `src/game`: 기존 경기·모션·3D·판정 코드, `markup.html`, CSS. Verse8에서 계속 수정할 수 있는 일반 소스입니다.
- `public/assets`: 인체 버퍼와 텍스처. 앱은 이 파일을 불러온 뒤 시작합니다.
- `vite.config.ts`: 상대 경로 빌드. 게임 파일 변경 시 전체 새로고침으로 단일 RAF 루프와 이벤트 리스너를 교체합니다.
- `SOURCE-PROVENANCE.json`: 이식된 게임 모듈의 무결성 확인용 해시.
- `scripts/prepare-source.mjs`: 이 작업 공간의 형제 폴더 `../touchline/dist`에서 최신 소스를 가져오는 유지보수용 스크립트입니다. ZIP만 받은 경우 실행할 필요 없습니다. 이미 `src/game`이 포함되어 있습니다.

기존 게임은 DOM을 직접 조작하므로 HUD를 React 상태로 다시 렌더링하거나 StrictMode 효과에서 게임을 두 번 시작하면 안 됩니다. 계정별 기록이나 경쟁 랭킹을 추가할 때는 Verse8 SDK에 연결하고 점수 검증은 서버에서 처리해야 합니다.

## 확인한 공식 자료

- [Verse8 Vite·React 개발 환경](https://docs.verse8.io/en/docs/gameserver/sdk/gettingStarted)
- [파일 첨부 안내](https://docs.verse8.io/en/docs/guide/prompt)
- [Three.js를 포함한 vanilla 게임 UI 지원 안내](https://docs.verse8.io/en/docs/vxshop/implementing-shop-vanilla)
- [Preview·Code·Launch 편집기](https://docs.verse8.io/en/docs/guide/editor)

플랫폼 호환성은 위 자료와 현재 코드 구조에 근거한 판단입니다. 실제 Verse8 런타임 검증은 새 프로젝트를 만든 뒤 남아 있습니다. 이식 자체가 모델이나 애니메이션의 품질을 자동 개선하지는 않습니다.


## 이번 준비 환경의 검증 범위

DOM 이벤트 검사는 실제 게임 app.js와 판정·커리어 로직을 사용하되 3D 렌더러 대역으로 수행합니다. 단독 HTML/Verse8의 원본 코드와 모델·텍스처 바이트 일치 검사 및 프로덕션 빌드는 별도로 실행합니다. Verse8에 이식한 뒤 Preview에서 WebGL과 전체 화면을 확인하세요.
