import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';

const root = path.resolve(import.meta.dirname, '..');
const gameRoot = path.resolve(process.env.TOUCHLINE_GAME_SOURCE ?? path.join(root, '../touchline'));
const source = path.join(gameRoot, 'dist');
const hash = content => createHash('sha256').update(content).digest('hex');

async function relativeFiles(directory, prefix = '') {
  const files = [];
  for (const entry of await fs.readdir(directory, {withFileTypes: true})) {
    const name = path.posix.join(prefix, entry.name);
    if (entry.isDirectory()) files.push(...await relativeFiles(path.join(directory, entry.name), name));
    else if (entry.isFile()) files.push(name);
  }
  return files.sort();
}

test('ported gameplay and binary assets match the packaged source', async () => {
  const manifest = JSON.parse(await fs.readFile(path.join(root, 'SOURCE-PROVENANCE.json'), 'utf8'));
  const gamePackage = JSON.parse(await fs.readFile(path.join(gameRoot, 'package.json'), 'utf8'));
  assert.equal(manifest.gameVersion, gamePackage.version);
  const canonicalNames = (await fs.readdir(source)).filter(name => /\.(js|mjs)$/.test(name)).sort();
  assert.deepEqual(Object.keys(manifest.files).sort(), canonicalNames, 'all canonical game modules must be ported');
  for (const [name, checksum] of Object.entries(manifest.files)) {
    const content = await fs.readFile(path.join(root, 'src/game', name));
    assert.equal(hash(content), checksum, name);
    const canonical = (await fs.readFile(path.join(source, name), 'utf8'))
      .replaceAll("from './vendor/three.module.js'", "from 'three'");
    assert.equal(content.toString('utf8'), canonical, name);
  }

  const assets = await relativeFiles(path.join(source, 'assets'));
  assert.deepEqual(Object.keys(manifest.assets).sort(), assets, 'all canonical assets must be ported');
  assert.deepEqual(await relativeFiles(path.join(root, 'public/assets')), assets, 'no stale assets should ship');
  for (const [name, asset] of Object.entries(manifest.assets)) {
    const bytes = await fs.readFile(path.join(root, 'public/assets', name));
    assert.equal(bytes.length, asset.bytes, name);
    assert.equal(hash(bytes), asset.sha256, name);
    assert.deepEqual(bytes, await fs.readFile(path.join(source, 'assets', name)), name);
  }
});

test('React mounts the same startup mode, controls and theme as the local game', async () => {
  const app = await fs.readFile(path.join(root, 'src/game/app.js'), 'utf8');
  const markup = await fs.readFile(path.join(root, 'src/game/markup.html'), 'utf8');
  for (const match of app.matchAll(/\$\('([^']+)'\)/g)) {
    assert.ok((markup + app).includes('id="' + match[1] + '"'), match[1]);
  }
  const html = await fs.readFile(path.join(source, 'index.html'), 'utf8');
  const canonicalMarkup = html.match(/<body\b[^>]*>([\s\S]*?)<script type="module" src="\.\/app\.js"><\/script>\s*<\/body>/)?.[1];
  assert.equal(markup, canonicalMarkup, 'complete mounted markup matches canonical source');
  const css = await fs.readFile(path.join(root, 'src/game/style.css'), 'utf8');
  assert.equal(css, await fs.readFile(path.join(source, 'style.css'), 'utf8'), 'the complete game theme is retained');
  const wrapper = await fs.readFile(path.join(root, 'index.html'), 'utf8');
  for (const pattern of [/<body\b[^>]*>/, /<meta name="theme-color"[^>]*>/, /<link rel="icon"[^>]*>/]) {
    assert.equal(wrapper.match(pattern)?.[0], html.match(pattern)?.[0]);
  }
  assert.doesNotMatch(markup, /<script/);
  assert.doesNotMatch(css, /@import/);
});

