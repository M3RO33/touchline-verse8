// Local, self-contained model assets. See ASSET-CREDITS.txt.
export const ATHLETE_RESOURCES = {
  geometry: './assets/athlete-geometry.bin',
  body: './assets/rocketbox-body.jpg',
  head: './assets/rocketbox-head.jpg',
  bodyNormal: './assets/rocketbox-body-normal.png',
  headNormal: './assets/rocketbox-head-normal.png',
};
