import {ROCKETBOX_GAIT} from './rocketbox-gait.mjs';

const clamp = (value, low = 0, high = 1) => Math.max(low, Math.min(high, value));
const lerp = (from, to, weight) => from + (to - from) * weight;
const smooth = value => {
  const weight = clamp(value);
  return weight * weight * (3 - 2 * weight);
};

function curve(frames, phase, channel, angle = false) {
  const frame = (phase - Math.floor(phase)) * frames.length;
  const index = Math.floor(frame);
  const fraction = frame - index;
  const get = i => frames[(i + frames.length) % frames.length][channel];
  const current = get(index);
  const unwrap = value => angle
    ? current + Math.atan2(Math.sin(value - current), Math.cos(value - current))
    : value;
  const previous = unwrap(get(index - 1));
  const next = unwrap(get(index + 1));
  const afterNext = unwrap(get(index + 2));
  return current + .5 * fraction * (next - previous + fraction * (
    2 * previous - 5 * current + 4 * next - afterNext
    + fraction * (3 * (current - next) + afterNext - previous)
  ));
}

export function sampleAuthoredGait(kind, phase) {
  const clip = ROCKETBOX_GAIT[kind];
  const frames = clip.frames;
  const angles = (channel, count = 3) => Array.from({length: count}, (_, axis) =>
    curve(frames, phase, channel + axis, true));
  return {
    source: clip.source,
    duration: clip.duration,
    hip: curve(frames, phase, 0) - clip.meanHip,
    sway: curve(frames, phase, 1) - clip.meanSway,
    body: angles(3),
    torso: angles(6),
    spine: angles(6).map(value => value * .42),
    chest: angles(6).map(value => value * .58),
    head: angles(9),
    arms: [angles(12), angles(15)],
    elbows: angles(18, 2),
  };
}

export function sampleAuthoredSwing(kind, foot, phase) {
  const clip = ROCKETBOX_GAIT[kind];
  const frames = clip.feet[foot];
  const support = clip.sourceStance[foot];
  const at = support + (1 - support) * clamp(phase);
  const start = curve(frames, support, 0);
  const end = curve(frames, 0, 0);
  const span = end - start;
  const fromHeight = curve(frames, support, 1);
  const toHeight = curve(frames, 0, 1);
  return {
    progress: Math.abs(span) > .05 ? (curve(frames, at, 0) - start) / span : phase,
    lift: Math.max(0, curve(frames, at, 1) - lerp(fromHeight, toHeight, smooth(phase))),
    pitch: clamp(curve(frames, at, 2, true), -.65, 1.05),
  };
}
