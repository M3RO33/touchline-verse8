// All distances are metres, velocities m/s and angular velocities rad/s.
export const BALL_RADIUS = .115;
export const GRAVITY = 9.81;
const STEP = 1 / 240;
const AIR_DRAG = .011;
const MAGNUS = .0028;
const SHELL_INERTIA = 2 / 3;
const UP = [0, 1, 0];

const add = (a, b) => a.map((x, i) => x + b[i]);
const scale = (v, k) => v.map(x => x * k);
const subtract = (a, b) => a.map((x, i) => x - b[i]);
const dot = (a, b) => a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
const cross = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
const length = v => Math.hypot(...v);
const clamp = (n, low, high) => Math.min(high, Math.max(low, n));
const lerp = (a, b, q) => a.map((x, i) => x + (b[i] - x) * q);
const makeState = (position, velocity, spin, bounces = 0) => ({position, velocity, spin, bounces});

function airAcceleration(velocity, spin, {drag, magnus}) {
  const acceleration = add(scale(velocity, -drag * length(velocity)), scale(cross(spin, velocity), magnus));
  acceleration[1] -= GRAVITY;
  return acceleration;
}

function advanceAir(state, dt, settings) {
  const midSpin = scale(state.spin, Math.exp(-.11 * dt));
  const midVelocity = add(state.velocity, scale(airAcceleration(state.velocity, state.spin, settings), .5 * dt));
  return makeState(
    add(state.position, scale(midVelocity, dt)),
    add(state.velocity, scale(airAcceleration(midVelocity, midSpin, settings), dt)),
    scale(state.spin, Math.exp(-.22 * dt)),
    state.bounces
  );
}

function applyFriction(state, normal, maxImpulse, radius) {
  const offset = scale(normal, -radius);
  const contactVelocity = add(state.velocity, cross(state.spin, offset));
  const tangent = subtract(contactVelocity, scale(normal, dot(contactVelocity, normal)));
  const slip = length(tangent);
  if (slip < 1e-9) return;
  const impulse = scale(tangent, -Math.min(1 / (1 + 1 / SHELL_INERTIA), maxImpulse / slip));
  state.velocity = add(state.velocity, impulse);
  state.spin = add(state.spin, scale(cross(offset, impulse), 1 / (SHELL_INERTIA * radius ** 2)));
}

function bounce(state, normal, restitution, grip, radius) {
  const approach = dot(state.velocity, normal);
  if (approach >= 0) return;
  const normalImpulse = -(1 + restitution) * approach;
  state.velocity = add(state.velocity, scale(normal, normalImpulse));
  applyFriction(state, normal, grip * normalImpulse, radius);
}

function advanceGround(state, dt, {radius, friction}) {
  const next = makeState(state.position.slice(), state.velocity.slice(), state.spin.slice(), state.bounces);
  next.position[1] = radius;
  next.velocity[1] = 0;
  applyFriction(next, UP, .47 * GRAVITY * dt, radius);
  const [vx,,vz] = next.velocity;
  const sliding = Math.hypot(vx + radius*next.spin[2], vz - radius*next.spin[0]) > .015;
  const speed = Math.hypot(vx, vz);
  const loss = sliding ? .25 * friction : friction;
  const movingTime = speed > 0 ? Math.min(dt, speed / Math.max(loss, 1e-9)) : 0;
  const travel = movingTime * (speed - .5 * loss * movingTime);
  if (speed > 0) {
    next.position[0] += vx / speed * travel;
    next.position[2] += vz / speed * travel;
  }
  next.velocity = scale(next.velocity, speed > 0 ? Math.max(0, 1 - loss*dt/speed) : 0);
  next.spin[1] *= Math.exp(-2.1 * dt);
  if (!sliding) {
    next.spin[0] = next.velocity[2] / radius;
    next.spin[2] = -next.velocity[0] / radius;
  }
  return next;
}

function advanceWithTurf(state, dt, settings) {
  const {radius, restitution} = settings;
  if (state.position[1] <= radius + 1e-8 && Math.abs(state.velocity[1]) < .001) {
    return advanceGround(state, dt, settings);
  }
  const airborne = advanceAir(state, dt, settings);
  if (airborne.position[1] >= radius) return airborne;

  // Find the floor contact inside this step so hard landings do not sink into turf.
  let lo = 0, hi = dt;
  for (let i = 0; i < 10; i++) {
    const mid = (lo + hi) * .5;
    if (advanceAir(state, mid, settings).position[1] > radius) lo = mid;
    else hi = mid;
  }
  const hit = advanceAir(state, hi, settings);
  hit.position[1] = radius;
  const impactSpeed = -hit.velocity[1];
  const lively = impactSpeed * restitution >= .40;
  bounce(hit, UP, lively ? restitution : 0, .32, radius);
  if (lively) hit.bounces++;
  const next = lively ? advanceAir(hit, dt - hi, settings) : advanceGround(hit, dt - hi, settings);
  next.position[1] = Math.max(radius, next.position[1]);
  return next;
}

function collideGoal(state, radius, net) {
  const [x, y, z] = state.position;
  if (Math.abs(x) < 51.9 || y > 2.8 || Math.abs(z) > 4) return;
  const sign = Math.sign(x), postX = sign * 52.5;
  const points = [
    [postX, clamp(y, 0, 2.44), -3.66],
    [postX, clamp(y, 0, 2.44), 3.66],
    [postX, 2.44, clamp(z, -3.66, 3.66)]
  ];
  for (const point of points) {
    const offset = subtract(state.position, point), gap = length(offset);
    if (gap >= radius + .06) continue;
    const normal = gap > 1e-8 ? scale(offset, 1/gap) : [-sign, 0, 0];
    state.position = add(point, scale(normal, radius + .06001));
    bounce(state, normal, .67, .23, radius);
  }
  // The back and sides of a goal net absorb most of the ball's energy.
  if (!net || state.position[0] * sign < 52.5 + radius || y > 2.44 + radius) return;
  for (const [axis, side, limit] of [[0,sign,55-radius],[2,1,3.66-radius],[2,-1,3.66-radius],[1,1,2.44-radius]]) {
    if (state.position[axis] * side <= limit) continue;
    const normal = [0, 0, 0];
    normal[axis] = -side;
    state.position[axis] = side * limit;
    bounce(state, normal, .12, .55, radius);
    state.velocity = scale(state.velocity, .56);
    state.spin = scale(state.spin, .62);
  }
}

export function createBallTrack(start, velocity, {
  spin = [0, 0, 0], radius = BALL_RADIUS, restitution = .53, friction = .91,
  drag = AIR_DRAG, magnus = MAGNUS, goalFrame = false, net = false
} = {}) {
  const settings = {radius, restitution, friction, drag, magnus};
  const position = start.slice();
  position[1] = Math.max(radius, position[1]);
  const frames = [makeState(position, velocity.slice(), spin.slice())];

  return {
    at(elapsed) {
      const time = Math.max(0, elapsed);
      const index = Math.floor(time / STEP);
      while (frames.length <= index + 1) {
        const next = advanceWithTurf(frames.at(-1), STEP, settings);
        if (goalFrame) collideGoal(next, radius, net);
        next.position[1] = Math.max(radius, next.position[1]);
        frames.push(next);
      }
      const a = frames[index], b = frames[index + 1], fraction = time / STEP - index;
      return makeState(lerp(a.position,b.position,fraction),lerp(a.velocity,b.velocity,fraction),
        lerp(a.spin,b.spin,fraction), a.bounces);
    }
  };
}

// Plan a receiving touch so the ball can roll to the following scene's
// position and speed under the same friction as every other ground ball.
export function createRollingArrival(end, duration, direction, endSpeed) {
  const friction = .91;
  const initialSpeed = endSpeed + friction * duration;
  const distance = (initialSpeed + endSpeed) * .5 * duration;
  const start = [end[0] - direction[0]*distance, end[1], end[2] - direction[1]*distance];
  const velocity = [direction[0]*initialSpeed, 0, direction[1]*initialSpeed];
  const spin = [velocity[2]/BALL_RADIUS, 0, -velocity[0]/BALL_RADIUS];
  const roll = createBallTrack(start,velocity,{spin,friction});
  return {start,at:elapsed=>roll.at(elapsed)};
}

function airborneKick(start, end, duration, {kind, drag, magnus, radius, friction}) {
  const [dx, dy, dz] = subtract(end, start);
  const distance = Math.hypot(dx, dz) || 1;
  const nx = dx / distance, nz = dz / distance;
  const turn = Math.sign(dx || 1);
  const spin = kind === 'shot' ? [18*nz, 5*turn, -18*nx] : [-28*nz, 12*turn, 28*nx];
  const steps = Math.ceil(duration / STEP), dt = duration / steps;
  const settings = {drag, magnus};
  const run = (velocity, frames) => {
    let state = makeState(start, velocity, spin);
    frames?.push(state);
    for (let i = 0; i < steps; i++) {
      state = advanceAir(state, dt, settings);
      frames?.push(state);
    }
    return state;
  };

  // Fit the kick impulse to the planned contact position. There are no
  // position corrections during play, and the ball still reacts to air forces.
  let velocity = [dx / duration, dy / duration + .5 * GRAVITY * duration, dz / duration];
  for (let i = 0; i < 16; i++) {
    const miss = subtract(end, run(velocity).position);
    if (length(miss) < .0000003) break;
    velocity = add(velocity, scale(miss, (1 + .75*drag*distance) / duration));
  }
  const frames = [];
  run(velocity, frames);
  const final = frames.at(-1);
  const continuation = createBallTrack(end,final.velocity,{spin:final.spin,radius,friction,drag,magnus});
  return {
    at(elapsed) {
      if (elapsed <= 0) return makeState(start.slice(),velocity.slice(),spin.slice());
      if (elapsed >= duration) return continuation.at(elapsed-duration);
      const phase = elapsed / dt, index = Math.min(steps-1,Math.floor(phase)), q = phase-index;
      const a = frames[index], b = frames[index+1];
      const position = a.position.map((p,i) => {
        const d = b.position[i] - p, av = a.velocity[i]*dt, bv = b.velocity[i]*dt;
        return p + q*(av + q*(3*d - 2*av - bv + q*(av+bv-2*d)));
      });
      position[1] = Math.max(radius, position[1]);
      return makeState(position, lerp(a.velocity,b.velocity,q), lerp(a.spin,b.spin,q));
    }
  };
}

// Fit the initial strike speed once. The live ball then samples the same
// contact/friction integrator as a deflection or drop.
function surfaceKick(start, end, duration, {kind, friction, radius, drag, magnus}) {
  const [dx,,dz] = subtract(end,start);
  const distance = Math.hypot(dx,dz);
  const [nx,nz] = distance > 1e-8 ? [dx/distance,dz/distance] : [0,0];
  const driven = kind === 'driven', parry = kind === 'parry';
  const landingPass = kind === 'landing-pass';
  const roll = kind === 'dribble' ? .74 : driven ? .31 : parry ? .10 : .54;
  // Skipping passes strike the turf before reaching the receiver.
  // Limit their backspin so a fast strike still comes down in time.
  const lift = landingPass ? GRAVITY*duration*.255
    : driven ? Math.min(3.55, GRAVITY * duration * .245) : parry ? .78 : 0;
  const restitution = landingPass ? .32 : driven || parry ? .43 : .47;
  const measure = speed => {
    const rotation = landingPass ? -Math.min(24,.13*speed/radius) : speed*roll/radius;
    const spin = [nz*rotation,0,-nx*rotation];
    const track = createBallTrack(start,[nx*speed,lift,nz*speed],{spin,radius,restitution,friction,drag,magnus});
    const arrival = track.at(duration);
    const displacement = (arrival.position[0]-start[0])*nx + (arrival.position[2]-start[2])*nz;
    return {speed,miss:distance-displacement,track,arrival};
  };
  let earlier, solution = measure(distance/duration + .5*friction*duration);
  for(let i=0;i<12 && Math.abs(solution.miss)>1e-7;i++){
    const slope = earlier && (earlier.miss-solution.miss)/(solution.speed-earlier.speed);
    const response = Number.isFinite(slope) && slope>duration*.12 ? slope : duration*.80;
    const speed = Math.max(0,solution.speed+solution.miss/response);
    earlier=solution;
    solution=measure(speed);
  }
  // A tiny touch can stop before the arrival time and flatten the local
  // response. Bracket that low-speed case instead of nudging the position.
  if(Math.abs(solution.miss)>1e-6){
    let low=0,high=Math.max(solution.speed,distance/duration+friction*duration+.1);
    for(let i=0;i<28 && Math.abs(solution.miss)>1e-7;i++){
      solution=measure((low+high)*.5);
      if(solution.miss>0)low=solution.speed;
      else high=solution.speed;
    }
  }
  return {
    at(elapsed) {
      if(elapsed !== duration) return solution.track.at(elapsed);
      const arrival = solution.arrival;
      // Preserve the authored contact coordinate to floating point precision.
      const position = length(subtract(end,arrival.position))<.00001 ? end.slice() : arrival.position.slice();
      return makeState(position,arrival.velocity.slice(),arrival.spin.slice(),arrival.bounces);
    }
  };
}

export function createPassTrack(start, end, duration, {
  loft = false, kind = 'pass', friction = 1.15, radius = BALL_RADIUS,
  drag = AIR_DRAG, magnus = MAGNUS
} = {}) {
  const flight = Math.max(.001, duration);
  if (loft || kind==='cross' || Math.abs(start[1]-radius)>1e-5 || Math.abs(end[1]-radius)>1e-5) {
    return airborneKick(start,end,flight,{kind,drag,magnus,radius,friction});
  }
  return surfaceKick(start,end,flight,{kind,friction,radius,drag,magnus});
}

export function createParryTrack(start, end, duration) {
  return surfaceKick(start,end,Math.max(1.2,duration),{
    kind:'parry',friction:.91,radius:BALL_RADIUS,drag:AIR_DRAG,magnus:MAGNUS
  });
}

const passCache = new Map();
export function passTrack(start, end, duration, options = {}) {
  const {loft=false,kind='pass',friction=1.15,radius=BALL_RADIUS,drag=AIR_DRAG,magnus=MAGNUS} = options;
  const key = [...start,...end,duration,loft,kind,friction,radius,drag,magnus].join('|');
  if (!passCache.has(key)) {
    if (passCache.size >= 320) passCache.delete(passCache.keys().next().value);
    passCache.set(key, createPassTrack(start.slice(),end.slice(),duration,{loft,kind,friction,radius,drag,magnus}));
  }
  return passCache.get(key);
}

const looseCache = new Map();
export function looseBallTrack(start, velocity, options = {}) {
  const {spin=[0,0,0],radius=BALL_RADIUS,restitution=.53,friction=.91,drag=AIR_DRAG,magnus=MAGNUS,goalFrame=false,net=false} = options;
  const key = [...start,...velocity,...spin,radius,restitution,friction,drag,magnus,goalFrame,net].join('|');
  if (!looseCache.has(key)) {
    if (looseCache.size >= 192) looseCache.delete(looseCache.keys().next().value);
    looseCache.set(key, createBallTrack(start,velocity,{spin,radius,restitution,friction,drag,magnus,goalFrame,net}));
  }
  return looseCache.get(key);
}

