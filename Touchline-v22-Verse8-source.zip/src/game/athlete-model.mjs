import * as THREE from 'three';
import {ATHLETE_DATA} from './athlete-data.mjs';
import {ATHLETE_TEXTURES} from './athlete-textures.mjs';
const decoded = new Map(), geometryCache = new Map(), textureCache = new Map();
const palettes = {
  home: {shorts: '#172c40', socks: '#e9eee9', boots: '#dce7e9'},
  away: {shorts: '#202825', socks: '#ce5b39', boots: '#f0ddd0'},
  ref: {shorts: '#151c20', socks: '#222c30', boots: '#afb9bd'},
};
function base(lod) {
  if (decoded.has(lod)) return decoded.get(lod);
  const data = ATHLETE_DATA[lod];
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(data.position, 3));
  geometry.setAttribute('normal', new THREE.BufferAttribute(data.normal, 3, true));
  geometry.setAttribute('uv', new THREE.BufferAttribute(data.uv, 2));
  geometry.setAttribute('uv1', new THREE.BufferAttribute(data.uv1, 2));
  geometry.setAttribute('skinIndex', new THREE.BufferAttribute(data.skinIndex, 4));
  const weights = new Float32Array(data.skinWeight.length);
  for (let index = 0; index < weights.length; index += 4) {
    const total = data.skinWeight[index] + data.skinWeight[index + 1] + data.skinWeight[index + 2] + data.skinWeight[index + 3];
    for (let slot = 0; slot < 4; slot++) weights[index + slot] = data.skinWeight[index + slot] / total;
  }
  geometry.setAttribute('skinWeight', new THREE.BufferAttribute(weights, 4));
  geometry.setIndex(new THREE.BufferAttribute(data.index, 1));
  for (const group of data.groups) geometry.addGroup(group.start, group.count, group.materialIndex);
  const mesh = {g: geometry, kinds: data.kind};
  decoded.set(lod, mesh);
  return mesh;
}

export function athleteGeometry(lod, team) {
  const key = lod + '/' + team;
  if (geometryCache.has(key)) return geometryCache.get(key);
  const {g: template, kinds} = base(lod);
  const geometry = new THREE.BufferGeometry();
  for (const [name, attribute] of Object.entries(template.attributes)) geometry.setAttribute(name, attribute);
  geometry.setIndex(template.index);
  for (const group of template.groups) geometry.addGroup(group.start, group.count, group.materialIndex);
  const palette = palettes[team];
  const colors = {3: new THREE.Color(palette.shorts), 4: new THREE.Color(palette.socks), 6: new THREE.Color(palette.boots)};
  const rgb = new Float32Array(kinds.length * 3);
  rgb.fill(1);
  for (let index = 0; index < kinds.length; index++) colors[kinds[index]]?.toArray(rgb, index * 3);
  geometry.setAttribute('color', new THREE.BufferAttribute(rgb, 3));
  geometry.computeBoundingSphere();
  geometry.userData.source = 'Microsoft Rocketbox';
  geometry.userData.lod = lod;
  geometryCache.set(key, geometry);
  return geometry;
}
export function athleteTexture(name){
 if(textureCache.has(name))return textureCache.get(name);
 let resolve,reject;const ready=new Promise((yes,no)=>{resolve=yes;reject=no;});
 const tex=new THREE.TextureLoader().load(ATHLETE_TEXTURES[name],resolve,undefined,reject);
 tex.userData.ready=ready;tex.colorSpace=name.endsWith('Normal')?THREE.NoColorSpace:THREE.SRGBColorSpace;tex.anisotropy=4;textureCache.set(name,tex);return tex;
}
export function waitForAthleteTextures(){return Promise.all([...textureCache.values()].map(tex=>tex.userData.ready));}
function withClothContactGeometry(baseGeometry,lod){
 const g=new THREE.BufferGeometry();for(const [name,attribute]of Object.entries(baseGeometry.attributes))g.setAttribute(name,attribute);g.setIndex(baseGeometry.index);baseGeometry.groups.forEach(x=>g.addGroup(x.start,x.count,x.materialIndex));g.userData={...baseGeometry.userData};
 g.morphTargetsRelative=true;g.morphAttributes.position=[new THREE.Float32BufferAttribute(new Float32Array(g.attributes.position.count*3),3)];g.morphAttributes.position[0].name='clothGroundContact';g.userData.clothVertices=Array.from(base(lod).kinds.entries()).filter(([,kind])=>kind===3).map(([i])=>i);return g;
}
export function bindAthleteModel(p){
 const bones=[p.body,p.spine,p.chest,p.neck,p.headPivot,...p.legs.flatMap((b,i)=>[b,p.knees[i],p.feet[i]]),...p.arms.flatMap((b,i)=>[b,p.elbows[i],p.wrists[i],...p.digits[i].flatMap(d=>[d.b,d.distal])]),...p.brows,...p.lids,p.jaw],skeleton=new THREE.Skeleton(bones),lod=new THREE.LOD();
 p.skin=new THREE.SkinnedMesh(withClothContactGeometry(athleteGeometry('near',p.team),'near'),p.materials);p.farSkin=new THREE.SkinnedMesh(withClothContactGeometry(athleteGeometry('far',p.team),'far'),p.materials);p.modelLOD=lod;
 for(const mesh of [p.skin,p.farSkin]){mesh.castShadow=true;mesh.receiveShadow=true;mesh.frustumCulled=false;}
 lod.addLevel(p.skin,0);lod.addLevel(p.farSkin,16);p.group.add(lod);p.group.updateMatrixWorld(true);p.skin.bind(skeleton);p.farSkin.bind(skeleton,p.skin.bindMatrix);p.head=p.skin;p.shirt=p.skin;
}
const skinnedMatrix=new THREE.Matrix4(),inverseLinear=new THREE.Matrix3(),worldPoint=new THREE.Vector3(),delta=new THREE.Vector3(),meshUp=new THREE.Vector3();
export function updateClothContacts(p,state){
 const active=state.hip[1]<.60;
 for(const mesh of [p.skin,p.farSkin]){
  mesh.morphTargetInfluences[0]=0;if(!active)continue;
  const geometry=mesh.geometry,offset=geometry.morphAttributes.position[0],data=offset.array,skinIndex=geometry.attributes.skinIndex,skinWeight=geometry.attributes.skinWeight;data.fill(0);mesh.skeleton.update();const matrices=mesh.skeleton.boneMatrices;
  meshUp.set(0,1,0).applyMatrix3(new THREE.Matrix3().setFromMatrix4(mesh.matrixWorld).invert());
  let corrected=false;
  for(const i of geometry.userData.clothVertices){
   mesh.getVertexPosition(i,worldPoint);mesh.localToWorld(worldPoint);const penetration=.004-worldPoint.y;if(penetration<=0)continue;
   skinnedMatrix.elements.fill(0);for(let k=0;k<4;k++){const weight=skinWeight.array[i*4+k],index=skinIndex.array[i*4+k];if(!weight)continue;for(let j=0;j<16;j++)skinnedMatrix.elements[j]+=matrices[index*16+j]*weight;}
   skinnedMatrix.premultiply(mesh.bindMatrixInverse).multiply(mesh.bindMatrix);inverseLinear.setFromMatrix4(skinnedMatrix);if(Math.abs(inverseLinear.determinant())<.00001)continue;inverseLinear.invert();delta.copy(meshUp).multiplyScalar(penetration).applyMatrix3(inverseLinear);data.set(delta.toArray(),i*3);corrected=true;
  }
  if(corrected){offset.needsUpdate=true;mesh.morphTargetInfluences[0]=1;}
 }
}
