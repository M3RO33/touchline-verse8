const kicks = {
  tap: {body: .21, snap: .15, air: .07, pitch: 122, duration: .10},
  kick: {body: .33, snap: .24, air: .10, pitch: 111, duration: .14},
  chip: {body: .29, snap: .25, air: .13, pitch: 128, duration: .14},
  shot: {body: .43, snap: .31, air: .13, pitch: 102, duration: .19},
};
const whistles = {
  start: [[0, .235]],
  stop: [[0, .135], [.195, .235]],
  final: [[0, .135], [.195, .135], [.388, .31]],
};

function noiseSource(seed) {
  let state = seed;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 2147483648 - 1;
  };
}

function strikeSound({body, snap, air, pitch, duration}, sampleRate, variant) {
  const samples = new Float32Array(Math.ceil(duration * sampleRate));
  const noise = noiseSource(76377 + variant * 95849);
  let low = 0, edge = 0;
  for (let i = 0; i < samples.length; i++) {
    const t = i / sampleRate;
    const raw = noise();
    low += (raw - low) * .065;
    edge += (raw - edge) * .35;
    const attack = Math.min(1, t / .0027);
    const shell = Math.sin(2 * Math.PI * ((pitch + variant * 4) * t + .24 * (1 - Math.exp(-48*t)))) * Math.exp(-31*t);
    const seam = Math.sin(2 * Math.PI * (212 + variant*11) * t) * Math.exp(-57*t);
    const thump = body * (shell + .27 * seam + .62 * low * Math.exp(-38*t));
    const leather = snap * (edge - low) * Math.exp(-96*t);
    const scuff = air * (raw - edge) * Math.exp(-150*t);
    samples[i] = attack * (thump + leather + scuff) * Math.min(1, (duration-t)/.013);
  }
  return samples;
}

function whistleSound(pulses, sampleRate) {
  const duration = pulses.at(-1)[0] + pulses.at(-1)[1] + .004;
  const samples = new Float32Array(Math.ceil(duration * sampleRate));
  const noise = noiseSource(630007);
  for (let pulse = 0; pulse < pulses.length; pulse++) {
    const [start, length] = pulses[pulse];
    const base = Math.round(start * sampleRate);
    let smoothNoise = 0;
    for (let i = 0; i < Math.floor(length * sampleRate); i++) {
      const t = i / sampleRate, n = noise();
      smoothNoise += (n - smoothNoise) * .26;
      const gate = Math.min(1,t/.017) * Math.min(1,(length-t)/.037);
      const flutter = .74 + .16*Math.sin(2*Math.PI*37*t) + .10*Math.sin(2*Math.PI*59*t+.6);
      const bend = 80*t + 1.1*(Math.exp(-30*t)-1) - 48*t*t;
      const resonances = .125*Math.sin(2*Math.PI*(2515*t+bend))
        + .090*Math.sin(2*Math.PI*(3280*t+.71*bend))
        + .025*Math.sin(2*Math.PI*(5040*t+2*bend));
      samples[base+i] = gate * flutter * (resonances + .040*(n-smoothNoise));
    }
  }
  return samples;
}

export function renderPitchSound(name, sampleRate, variant = 0) {
  if (kicks[name]) return strikeSound(kicks[name], sampleRate, variant);
  if (whistles[name]) return whistleSound(whistles[name], sampleRate);
  return new Float32Array(0);
}

export function createPitchAudio(window, enabled) {
  let context, volume, variation = 0;
  const buffers = new Map();

  function unlock() {
    if (!enabled()) return;
    try {
      if (!context) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;
        context = new AudioContext();
        volume = context.createGain();
        volume.gain.value = .88;
        volume.connect(context.destination);
      }
      if (context.state === 'suspended') context.resume().catch(() => {});
    } catch {}
  }

  return {
    unlock,
    setEnabled(on) {
      if (volume) volume.gain.value = on ? .88 : 0;
    },
    play(name) {
      if (!enabled() || !context || !volume) return;
      try {
        const variant = kicks[name] ? variation++ % 3 : 0;
        const key = name + ':' + variant;
        if (!buffers.has(key)) {
          const samples = renderPitchSound(name, context.sampleRate, variant);
          if (!samples.length) return;
          const buffer = context.createBuffer(1, samples.length, context.sampleRate);
          buffer.getChannelData(0).set(samples);
          buffers.set(key, buffer);
        }
        const source = context.createBufferSource();
        source.buffer = buffers.get(key);
        source.connect(volume);
        source.start();
      } catch {}
    }
  };
}

// Sampling or seeking does not fire sounds. Only forward playback crosses a cue.
export function playPitchCues(audio, cues, before, after) {
  if (!(after > before)) return;
  for (const cue of cues) {
    if (before < cue.at && cue.at <= after) audio.play(cue.sound);
  }
}

