import {blendPose, clamp, ease, fitKickReach, lerp, localPoint, sampleIdle} from './motion.mjs';

const GROUND_ANKLE = .094;
const READY_AT = -.52;
const RECOVERED_AT = 1.14;

// Coordinates are local [forward, height, lateral] on the save side.
// Keep the opposite foot planted as the near foot steps, then release the
// opposite boot ahead of the near one. The late poses absorb the landing
// through the thigh and shoulder before the keeper puts a boot underneath.
function diveFrames(height, distance, direction) {
  const rise = clamp((height - .55) * .48, -.05, .33);
  const reach = distance - .9;
  const lowRoll = .15*(1-ease(.32,.60,height));
  const near = direction > 0 ? [.052,GROUND_ANKLE,.126] : [-.034,GROUND_ANKLE,.112];
  const far = direction > 0 ? [-.034,GROUND_ANKLE,-.112] : [.052,GROUND_ANKLE,-.126];
  const end = 1.26+reach;
  const endFoot = ([forward,y,lateral]) => [forward,y,end+lateral];
  return [
    // Time, pelvis, pelvis roll, dive-side foot, drive foot, two-hand midpoint.
    [READY_AT, [0,.97,0], .00, near, far, [.28,1.15,.00]],
    [-.34, [.035,.80,-.08], -.09, near, far, [.33,1.08,.00]],
    [-.25, [.05,.76,.025], .12, [.14,.17,.29], far, [.38,1.02,.18]],
    [-.17, [.06,.72,.20], .38, [.145,GROUND_ANKLE,.41], far, [.37,.98+rise*.30,.49]],
    [-.10, [.065,.63+rise*.37,.42+reach*.24], .64, [.145,.13,.41], [-.105,.20,.00], [.31,.91+rise*.82,.82+reach*.36]],
    [0, [.045,.46+rise,.81+reach], 1.09+lowRoll, [.035,.22+rise*.8,.52+reach*.58], [-.14,.28+rise*.7,.23+reach*.7], [.24,height,1.59+reach]],
    [.10, [.018,.30+rise*.4,1.03+reach], 1.20, [-.08,.15,.73+reach], [-.22,.24+rise*.25,.55+reach], [.24,.42+rise*.63,1.75+reach]],
    [.22, [-.015,.255,1.13+reach], 1.15, [-.12,.117,.79+reach], [-.17,.15,.65+reach], [.29,.33,1.77+reach]],
    [.40, [.005,.36,1.16+reach], .81, [-.04,.125,.90+reach], [.08,.155,.91+reach], [.36,.22,1.59+reach]],
    [.62, [.045,.51,1.17+reach], .35, [-.19,.123,1.07+reach], [.26,GROUND_ANKLE,1.22+reach], [.37,.53,1.42+reach]],
    [.83, [.065,.76,1.20+reach], .13, endFoot(near), [.26,GROUND_ANKLE,1.22+reach], [.29,.91,1.23+reach]],
    [.98, [.055,.89,1.23+reach], .06, endFoot(near), [.13,.18,1.18+reach], [.28,1.04,1.25+reach]],
    [RECOVERED_AT, [0,.97,1.26+reach], .00, endFoot(near), endFoot(far), [.28,1.15,1.26+reach]],
  ];
}

// Monotone interpolation keeps a planted boot fixed and carries speed through
// release, reach and landing. A direction change brings its own channel to rest.
function tangent(before, after) {
  return before * after <= 0 ? 0 : 2 * before * after / (before + after);
}

function sampleChannel(frames, i, elapsed, channel, component) {
  const value = j => component === undefined ? frames[j][channel] : frames[j][channel][component];
  const start = frames[i][0];
  const span = frames[i + 1][0] - start;
  const q = clamp((elapsed - start) / span);
  const a = value(i);
  const b = value(i + 1);
  const speed = (b - a) / span;
  const prior = i > 0 ? (a - value(i - 1)) / (start - frames[i - 1][0]) : 0;
  const following = i + 2 < frames.length
    ? (value(i + 2) - b) / (frames[i + 2][0] - frames[i + 1][0]) : 0;
  return lerp(a,b,q*q*(3-2*q)) + span*q*(1-q)
    *((1-q)*tangent(prior,speed)-q*tangent(speed,following));
}

/**
 * Sample a low or mid-height lateral save. Positive side is the positive
 * lateral axis of localPoint. Distance measures pelvis travel at ball reach.
 */
export function sampleKeeperDive(root, yaw, t, contactTime, {side = 1, height = .55, distance = .90} = {}) {
  const direction = side < 0 ? -1 : 1;
  const elapsed = t - contactTime;
  const frames = diveFrames(clamp(height,.32,1.27),clamp(distance,.61,1.19),direction);
  const last = frames.length - 1;
  const next = frames.findIndex(frame => elapsed < frame[0]);
  const segment = next < 0 ? last - 1 : Math.max(0,next - 1);
  const vector = channel => [0,1,2].map(component => sampleChannel(frames,segment,elapsed,channel,component));
  const point = ([forward,y,lateral]) => localPoint(root,yaw,forward,y,lateral*direction);
  const hipLocal = vector(1);
  const hip = point(hipLocal);
  const roll = direction * sampleChannel(frames,segment,elapsed,2);
  const [forward,handHeight,lateral] = vector(5);
  const nearFoot = vector(3);
  const farFoot = vector(4);
  const windup = ease(READY_AT,-.32,elapsed);
  const dive = ease(-.25,-.04,elapsed);
  const settle = ease(.13,.29,elapsed);
  const floorBrace = ease(.17, .275, elapsed) * (1 - ease(.315, .46, elapsed));
  const takeBall = ease(.03, .15, elapsed) * (1 - ease(.40, .64, elapsed));
  const recover = ease(.42,RECOVERED_AT,elapsed);
  const bootSettle = ease(.24,.47,elapsed);
  const pair = (near,far) => direction > 0 ? [near,far] : [far,near];
  const nearPlant = Math.max(1 - ease(-.345,-.285,elapsed),
    ease(-.249,-.175,elapsed) * (1 - ease(-.153,-.035,elapsed)), ease(.44,.72,elapsed));
  const farPlant = Math.max(1 - ease(-.179,-.06,elapsed),
    ease(.40,.615,elapsed) * (1 - ease(.84,.98,elapsed)), ease(.95,1.14,elapsed));
  const freeNear = lerp(.35,1,ease(-.145,-.025,elapsed));
  const reachOffset = clamp(distance, .61, 1.19) - .90;
  // Bring the near palm up to the surface of the ball at the parry.
  const parryReach = ease(-.19,-.045,elapsed) * (1 - ease(.04,.21,elapsed));
  const nearHand = point([
    lerp(forward + .008 - .156 * parryReach, .14, floorBrace),
    lerp(handHeight - .032, .038, floorBrace) + .044 * floorBrace * (2 - floorBrace),
    lerp(.04 + lateral, 1.66 + reachOffset, floorBrace),
  ]);
  const farHand = point([
    forward + .035 - .045 * takeBall - .21 * parryReach,
    handHeight + .082 + .035 * takeBall,
    lateral - .055 - .08 * takeBall,
  ]);
  const [hipForward,hipHeight,hipLateral] = hipLocal;
  const pose = fitKickReach({
    hip, yaw, time:t, action:'골키퍼 선방', roll,
    lean: (.15*windup-.26*dive+.22*settle)*(1-recover),
    spinePitch: .11*windup-.20*dive+.21*recover,
    chestPitch: -.08*dive*(1-recover),
    chestRoll: -direction*.09*dive*(1-recover),
    chestYaw: direction*.09*dive*(1-recover),
    headYaw: -direction*.26*dive*(1-recover),
    headRoll: -roll*.37,
    headPitch: -.09*dive*(1-recover),
    feet: pair(point(nearFoot),point(farFoot)),
    footPitch: pair(-.16*dive*(1-settle),.32*ease(-.20,-.09,elapsed)*(1-bootSettle)),
    footYaw: pair(-direction*.25,direction*.19),
    footRoll: pair(direction*.38*dive*(1-bootSettle),direction*.33*dive*(1-bootSettle)),
    bootContact: pair(nearPlant,farPlant),
    looseBoot: pair(freeNear,1),
    kneeHints: pair(
      point([hipForward+.37,hipHeight+.14,nearFoot[2]+.15]),
      point([hipForward+.25,hipHeight+.18,farFoot[2]-.10]),
    ),
    armPose: 'save', elbow: .45,
    handTargets: pair(nearHand,farHand),
    elbowHints: pair(
      point([forward-.18,handHeight-.12,lateral-.25]),
      point([forward+.10,handHeight+.22,lateral-.36]),
    ),
    handWeight: 1,
    handGroundWeight: pair(floorBrace, 0),
    handGrip: pair(.16 + .18 * takeBall - .10 * floorBrace, .16 + .44 * takeBall),
    handSpread: pair(.10 + .26 * floorBrace, .10 * (1 - takeBall)),
    wristPitch: pair(lerp(-.08, -.14, takeBall), lerp(-.08, .12, takeBall)),
    wristYaw: pair(-direction * .10 * takeBall, direction * .20 * takeBall),
    wristRoll: pair(direction * .07 * takeBall, -direction * .11 * takeBall),
    grip: .16 + .40 * settle * (1 - recover),
  });
  const [endX,,endZ] = point(frames[last][1]);
  if (elapsed < -.30) return blendPose(sampleIdle(root,yaw,t),pose,ease(READY_AT,-.30,elapsed));
  if (elapsed > 1.03) return blendPose(pose,sampleIdle([endX,endZ],yaw,t),ease(1.03,RECOVERED_AT,elapsed));
  return pose;
}

// Align the sideward reach with the shot without moving the planned ball.
// A scored shot goes to the opposite side of the keeper's dive.
export function sampleKeeperForShot(base,yaw,ball,t,contactTime,{goal=false}={}) {
  const forward=[Math.sin(yaw),Math.cos(yaw)], lateral=[-forward[1],forward[0]];
  const offset=(ball[0]-base[0])*lateral[0]+(ball[2]-base[1])*lateral[1];
  const side=Math.sign(offset)||1;
  if(goal)return sampleKeeperDive(base,yaw,t,contactTime,{side:-side,height:.55,distance:.90});
  const distance=clamp(Math.abs(offset)-.69,.61,1.19), reach=.69+distance;
  const start=[
    ball[0]-.24*forward[0]-side*reach*lateral[0],
    ball[2]-.24*forward[1]-side*reach*lateral[1]
  ];
  return sampleKeeperDive(start,yaw,t,contactTime,{side,height:ball[1],distance});
}
