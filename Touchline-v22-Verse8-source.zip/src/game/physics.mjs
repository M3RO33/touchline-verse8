import {passTrack,looseBallTrack} from './ball-physics.mjs';
export {GRAVITY} from './ball-physics.mjs';
export const PLAYER_GAP=.76;

export function samplePassPhysics(start,end,time,duration,options={}) {
  return passTrack(start,end,duration,options).at(time).position;
}

export function sampleLooseBall(start,velocity,time,options={}) {
  return looseBallTrack(start,velocity,options).at(time);
}

/** Deterministic two-dimensional contact solver. Pinned kickers/receivers have
 * zero mobility; the remaining players share separation by inverse mass. */
export function separatePlayers(points,{minimumGap=PLAYER_GAP,mobility=new Map(),axes=new Map(),onlyAxes=false,iterations=5}={}){
  const ids=[...points.keys()].sort(),result=new Map(ids.map(id=>[id,points.get(id).slice()]));
  for(let pass=0;pass<iterations;pass++)for(let i=0;i<ids.length;i++)for(let j=i+1;j<ids.length;j++){
    if(onlyAxes&&!axes.has(ids[i]+'|'+ids[j]))continue;
    const a=result.get(ids[i]),b=result.get(ids[j]),dx=b[0]-a[0],dz=b[1]-a[1],distance=Math.hypot(dx,dz),wa=mobility.get(ids[i])??1,wb=mobility.get(ids[j])??1,total=wa+wb;
    if(distance>=minimumGap||total===0)continue;
    const axis=axes.get(ids[i]+'|'+ids[j]),nx=axis?.[0]??(distance>1e-7?dx/distance:1),nz=axis?.[1]??(distance>1e-7?dz/distance:0),tangent=dx*nz-dz*nx,penetration=axis?Math.min((minimumGap-distance)*1.5,Math.max(0,Math.sqrt(Math.max(0,minimumGap**2-tangent*tangent))-(dx*nx+dz*nz))):minimumGap-distance,denominator=Math.max(1,total);
    a[0]-=nx*penetration*wa/denominator;a[1]-=nz*penetration*wa/denominator;b[0]+=nx*penetration*wb/denominator;b[1]+=nz*penetration*wb/denominator;
  }
  return result;
}
