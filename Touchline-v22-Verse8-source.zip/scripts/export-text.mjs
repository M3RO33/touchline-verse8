import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';

const root = path.resolve(import.meta.dirname, '..');
const provenance = JSON.parse(await fs.readFile(path.join(root, 'SOURCE-PROVENANCE.json'), 'utf8'));
async function walk(directory) {
  const entries = await fs.readdir(directory, {withFileTypes: true});
  const result = [];
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    if (['node_modules', '.build-cache', 'dist', '.git'].includes(entry.name)) continue;
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) result.push(...await walk(file));
    else result.push(file);
  }
  return result;
}

const files = await walk(root);
let text = 'TOUCHLINE Verse8 migration source / game ' + provenance.gameVersion
  + '\nBinary models and textures must be imported from the accompanying ZIP public/assets folder.\n';
for (const file of files) {
  const bytes = await fs.readFile(file);
  const relative = path.relative(root, file).replaceAll('\\', '/');
  const asset = relative.startsWith('public/assets/') && Object.hasOwn(provenance.assets, relative.slice(14));
  const binary = asset || /\.(bin|jpg|jpeg|png|webp|avif|ktx2|glb|wasm)$/i.test(file);
  const content = binary
    ? 'BINARY ASSET: use ' + relative + ' from the ZIP. ' + bytes.length + ' bytes; SHA256 '
      + createHash('sha256').update(bytes).digest('hex')
    : bytes.toString('utf8');
  text += '\n=== FILE: ' + relative + ' ===\n' + content + '\n=== END FILE ===\n';
}
await fs.writeFile(path.resolve(root, '../../outputs/Touchline-Verse8-source.txt'), text);
console.log('Exported ' + files.length + ' source entries.');

