import * as THREE from 'three';
import {sampleLocomotion,linearPath,clamp,lerp,ease,bootConstraint} from './motion.mjs';
import {bindAthleteModel,athleteTexture,updateClothContacts} from './athlete-model.mjs';
import {ATHLETE_FINGER_BIND} from './athlete-anchors.mjs';
const V=THREE.Vector3,DOWN=new V(0,-1,0),UPPER=.45,LOWER=.43,kitCache=new Map();
function cloth(team, number, base) {
  const key = team + ':' + number;
  if (kitCache.has(key)) return kitCache.get(key);
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  const home = team === 'home', referee = team === 'ref';
  const accent = home ? '#152e46' : referee ? '#17344f' : '#381c19';
  const ink = home && number !== 1 ? '#152e46' : '#f8f7ec';
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = accent;
  ctx.fillRect(0, 0, canvas.width, 18);
  ctx.fillRect(0, 493, canvas.width, 19);
  for (const center of [0, 512, 1024]) {
    ctx.fillRect(center - 22, 0, 44, 512);
    ctx.fillRect(center - 30, 0, 2, 512);
    ctx.fillRect(center + 28, 0, 2, 512);
  }
  ctx.textAlign = 'center';
  ctx.fillStyle = accent;
  ctx.fillRect(288, 138, 35, 41);
  ctx.fillStyle = base;
  ctx.font = 'bold 23px Arial';
  ctx.fillText(home ? 'N' : referee ? 'R' : 'E', 305, 166);
  if (!referee) {
    ctx.fillStyle = ink;
    ctx.font = 'bold 29px Arial';
    ctx.fillText(home ? 'NORTH FC' : 'EAST UTD', 256, 252);
    ctx.font = 'bold 188px Arial';
    ctx.fillText(String(number), 768, 373);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.channel = 1;
  texture.anisotropy = 8;
  kitCache.set(key, texture);
  return texture;
}

function athleteMaterials(team, number, kit, textures) {
  const body = textures ? athleteTexture('body') : null;
  const head = textures ? athleteTexture('head') : null;
  const bodyNormal = textures ? athleteTexture('bodyNormal') : null;
  const headNormal = textures ? athleteTexture('headNormal') : null;
  const skinTints = ['#e3c9b7', '#fff0e8', '#eeded3', '#cfb7a7'];
  const skin = textures ? skinTints[number % skinTints.length] : '#b98f76';
  return [
    new THREE.MeshStandardMaterial({map: body, normalMap: bodyNormal, vertexColors: true, roughness: .58}),
    new THREE.MeshStandardMaterial({color: textures ? '#ffffff' : kit, map: textures ? cloth(team, number, kit) : null, normalMap: bodyNormal, normalScale: new THREE.Vector2(.68, .68), roughness: .88}),
    new THREE.MeshStandardMaterial({color: skin, map: body, normalMap: bodyNormal, normalScale: new THREE.Vector2(.55, .55), roughness: .73}),
    new THREE.MeshStandardMaterial({normalMap: bodyNormal, normalScale: new THREE.Vector2(.63, .63), vertexColors: true, roughness: .9}),
    new THREE.MeshStandardMaterial({color: textures ? '#ffffff' : '#d3b8a9', map: head, roughness: .31}),
    new THREE.MeshStandardMaterial({color: skin, map: head, normalMap: headNormal, normalScale: new THREE.Vector2(.58, .58), roughness: .70}),
  ];
}

function bindFinger(wrist, sideIndex, index) {
  const [root, joint, tip] = ATHLETE_FINGER_BIND[sideIndex][index].map(point => new V(...point));
  const bone = new THREE.Bone(), distal = new THREE.Bone();
  bone.position.copy(root);
  bone.quaternion.setFromUnitVectors(DOWN, joint.clone().normalize());
  const inverse = bone.quaternion.clone().invert();
  distal.position.copy(joint.applyQuaternion(inverse));
  distal.quaternion.copy(inverse.multiply(new THREE.Quaternion().setFromUnitVectors(DOWN, tip.normalize())));
  bone.add(distal);
  wrist.add(bone);
  return {b:bone,distal,thumb:index===4,bind:bone.quaternion.clone(),distalBind:distal.quaternion.clone(),side:sideIndex?1:-1};
}
export function createFootballer(scene,team,number,{textures=true}={}){
 const group=new THREE.Group(),body=new THREE.Bone();group.add(body);body.position.y=.94;
 const spine=new THREE.Bone(),chest=new THREE.Bone(),neck=new THREE.Bone(),headPivot=new THREE.Bone();spine.position.y=.18;chest.position.y=.23;neck.position.y=.16;headPivot.position.y=.09;body.add(spine);spine.add(chest);chest.add(neck);neck.add(headPivot);
 const home=team==='home',ref=team==='ref',keeper=number===1,kit=ref?'#2477bc':keeper?(home?'#537d9e':'#827628'):home?'#ebede4':'#d85c37';
 const materials=athleteMaterials(team,number,kit,textures);
 const legs=[],knees=[],feet=[],arms=[],elbows=[],wrists=[],digits=[];
 for(const side of [-1,1]){
  const thigh=new THREE.Bone();thigh.position.set(side*.104,-.03,0);body.add(thigh);legs.push(thigh);const shin=new THREE.Bone();shin.position.y=-UPPER;thigh.add(shin);knees.push(shin);const foot=new THREE.Bone();foot.position.y=-LOWER;shin.add(foot);feet.push(foot);
  const arm=new THREE.Bone();arm.position.set(side*.226,.515,0);body.add(arm);arms.push(arm);const fore=new THREE.Bone();fore.position.y=-.29;arm.add(fore);elbows.push(fore);const wrist=new THREE.Bone();wrist.position.y=-.245;fore.add(wrist);wrists.push(wrist);const hand=[];
  for(let j=0;j<5;j++)hand.push(bindFinger(wrist,side<0?0:1,j));
  digits.push(hand);
 }
 const brows=[],lids=[];for(const side of [-1,1]){const b=new THREE.Bone();b.position.set(side*.039,.110,.098);headPivot.add(b);brows.push(b);const lid=new THREE.Bone();lid.position.set(side*.039,.095,.103);headPivot.add(lid);lids.push(lid);}const jaw=new THREE.Bone();jaw.position.set(0,.028,.026);headPivot.add(jaw);
 group.updateMatrixWorld(true);arms.forEach(a=>chest.attach(a));
 const shadow=new THREE.Mesh(new THREE.CircleGeometry(.40,28),new THREE.MeshBasicMaterial({color:'#152c1c',transparent:true,opacity:.17,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.018;group.add(shadow);const ring=new THREE.Mesh(new THREE.RingGeometry(.48,.495,48),new THREE.MeshBasicMaterial({color:home?'#80e4f4':'#df9df1',transparent:true,opacity:.65,side:THREE.DoubleSide,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.y=.035;ring.visible=false;group.add(ring);
 let labelTexture=null;if(textures){const c=document.createElement('canvas');c.width=192;c.height=72;const ctx=c.getContext('2d');ctx.fillStyle='#14231ddd';ctx.fillRect(25,12,142,47);ctx.fillStyle=home?'#cbf1f5':'#f9d0f7';ctx.textAlign='center';ctx.font='bold 32px Arial';ctx.fillText((home?'N':'E')+' #'+number,96,47);labelTexture=new THREE.CanvasTexture(c);}const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:labelTexture,transparent:true,depthTest:false,opacity:.9}));sprite.position.y=2.0;sprite.scale.set(.78,.29,1);sprite.visible=false;group.add(sprite);
 const p={group,body,spine,chest,neck,headPivot,legs,knees,feet,arms,elbows,wrists,digits,brows,lids,jaw,shadow,ring,sprite,team,number,id:team+'-'+number,base:new V(),bootColor:ref?'#17272c':home?'#4bc4ce':'#ebc862',materials,build:1,faceWidth:1};bindAthleteModel(p);
 if(ref){
  const dark=new THREE.MeshStandardMaterial({color:'#23383c',roughness:.75}),badge=new THREE.MeshStandardMaterial({color:'#e4eddd',roughness:.7});
  const add=(geo,mat,pos,parent)=>{const m=new THREE.Mesh(geo,mat);m.position.set(...pos);m.castShadow=true;parent.add(m);return m;};
  add(new THREE.BoxGeometry(.095,.008,.007),dark,[-.095,.40,.14],body);add(new THREE.BoxGeometry(.095,.008,.007),dark,[.095,.40,.14],body);add(new THREE.BoxGeometry(.042,.056,.006),badge,[-.095,.357,.139],body);
  add(new THREE.BoxGeometry(.038,.031,.013),dark,[0,.003,.027],wrists[0]);add(new THREE.BoxGeometry(.046,.073,.022),dark,[.17,.04,0],body);add(new THREE.SphereGeometry(.012,10,8),dark,[.092,.065,.002],headPivot);
 }
 scene.add(group);return p;
}
export function solveLeg(p,index,target,hint){
 const hip=p.legs[index].position.clone();const local=p.body.worldToLocal(new V(...target)),delta=local.clone().sub(hip);const raw=delta.length(),length=Math.min(UPPER+LOWER-.001,Math.max(.03,raw));const direction=delta.normalize();
 const along=(UPPER*UPPER-LOWER*LOWER+length*length)/(2*length),height=Math.sqrt(Math.max(0,UPPER*UPPER-along*along));
 let pole=hint?p.body.worldToLocal(new V(...hint)).sub(hip):new V(0,0,1);pole.addScaledVector(direction,-pole.dot(direction));if(pole.lengthSq()<.001)pole=new V(1,0,0);pole.normalize();
 const centre=hip.clone().addScaledVector(direction,along),up=new V(0,1,0).applyQuaternion(p.body.getWorldQuaternion(new THREE.Quaternion()).invert()),baseY=p.body.localToWorld(centre.clone()).y;
 // Keep the anatomical knee pole above the turf during a fall or a get-up.
 // This changes the bend direction, never the requested ankle contact point.
 if(height>.001&&baseY+height*pole.dot(up)<.080){const lift=up.clone().addScaledVector(direction,-up.dot(direction)),available=lift.length();if(available>.001){lift.normalize();const amount=Math.min(1,Math.max(-1,(.080-baseY)/(height*available))),side=pole.clone().addScaledVector(lift,-pole.dot(lift));if(side.lengthSq()<.001)side.crossVectors(direction,lift);side.normalize();pole.copy(lift.multiplyScalar(amount).addScaledVector(side,Math.sqrt(1-amount*amount)));}}
 const knee=centre.addScaledVector(pole,height),ankle=hip.clone().addScaledVector(direction,length);
 // Build the leg around one hinge, even when the two segments nearly oppose.
 // Independent shortest-arc rotations used to turn the shin inside out here.
 const thigh=knee.clone().sub(hip).normalize(),shin=ankle.clone().sub(knee).normalize();
 const hinge=new V().crossVectors(pole,direction).normalize();
 p.legs[index].quaternion.copy(limbFrame(thigh,hinge));
 p.knees[index].rotation.set(thigh.angleTo(shin),0,0);
 return raw-(UPPER+LOWER);
}
const axisX=new V(1,0,0),axisY=new V(0,1,0),axisZ=new V(0,0,1);
function limbFrame(down,x){
 const y=down.clone().negate(),z=new V().crossVectors(x,y).normalize();
 return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,y,z));
}
function softLimit(v,lo,hi,width){
 if(v<lo+width)return lo+width+width*Math.tanh((v-lo-width)/width);
 if(v>hi-width)return hi-width+width*Math.tanh((v-hi+width)/width);
 return v;
}
const soleChecks=[[-.035,-.080,.195],[.034,-.080,.195],[0,-.086,.13],[0,-.077,-.07],[0,-.052,.243]].map(v=>new V(...v));
function turfOrientationGain(state,ankleY){
 return state.slide!==undefined||state.fall!==undefined||state.action==='골키퍼 선방'
  ? lerp(.18,1,ease(.10,.41,ankleY)):1;
}
function relaxedBoot(p,index,state,authored,weight){
 const bend=p.knees[index].rotation.x,side=index===0?-1:1;
 const roll=clamp((state.roll||0)*.12+side*.08,-.24,.24);
 const local=new THREE.Quaternion().setFromEuler(new THREE.Euler(
  lerp(.12,.48,ease(.18,2.25,bend)),side*.06,roll
 ));
 return authored.slerp(local,weight);
}
function poseLooseBoot(p,index,state,desired,parent,authored,lock,weight){
 const foot=p.feet[index],leg=p.legs[index];
 let clearance=0;
 for(let attempt=0;attempt<4;attempt++){
  const ankleY=foot.getWorldPosition(new V()).y;
  const initial=weight<1?fitAuthoredBoot(parent,authored,lock,ankleY,
    turfOrientationGain(state,ankleY)*(1-weight)):authored;
  const rotation=relaxedBoot(p,index,state,initial,weight);
  foot.quaternion.copy(rotation);
  const world=parent.clone().multiply(rotation);
  const depth=.014-ankleY-Math.min(...soleChecks.map(point=>point.clone().applyQuaternion(world).y));
  if(depth<=.001||attempt===3||clearance>=.19)break;
  // Keep the released ankle angle and adjust the ankle target to clear the
  // turf. The calf and knee bend again around this higher endpoint.
  clearance+=Math.min(.19-clearance,depth*ease(0,.013,depth)*ease(0,.42,weight));
  if(clearance<=0)break;
  const target=state.feet[index].slice();
  target[1]+=clearance;
  solveLeg(p,index,target,state.kneeHints?.[index]);
  leg.updateMatrixWorld(true);
  parent=p.knees[index].getWorldQuaternion(new THREE.Quaternion());
  authored=parent.clone().invert().multiply(desired);
 }
}
function poseBoot(p,index,state){
 const desired=p.group.quaternion.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(
  state.footPitch?.[index]||0,state.footYaw?.[index]||0,state.footRoll?.[index]||0)));
 const parent=p.knees[index].getWorldQuaternion(new THREE.Quaternion());
 const authored=parent.clone().invert().multiply(desired);
 const lock=bootConstraint(state,index);
 if(lock>=.9999){p.feet[index].quaternion.copy(authored);return;}
 const freeWeight=(state.looseBoot?.[index]??0)*(1-lock);
 if(freeWeight>0){
  poseLooseBoot(p,index,state,desired,parent,authored,lock,freeWeight);
  return;
 }
 const ankleY=p.feet[index].getWorldPosition(new V()).y;
 p.feet[index].quaternion.copy(fitAuthoredBoot(parent,authored,lock,ankleY,turfOrientationGain(state,ankleY)));
}
function fitAuthoredBoot(parent,authored,lock,ankleY,correctionScale){
 // Give the free boot room to move with the shin. Protect actual grass
 // and ball contacts from the anatomical limits.
 const f=axisZ.clone().applyQuaternion(authored),up=axisY.clone().applyQuaternion(authored);
 const pitch=Math.atan2(-f.y,f.z);
 // Make bounded corrections around the authored orientation rather than
 // slerping to a different frame. The latter can flip as its dot crosses 0.
 const pitchDelta=(softLimit(pitch,-.56,.94,.16)-pitch)*(1-ease(2.05,2.98,Math.abs(pitch)))*ease(.12,.55,Math.hypot(f.y,f.z));
 const yaw=Math.asin(clamp(f.x,-1,1));
 const yawDelta=(softLimit(yaw,-.45,.45,.16)-yaw)*(1-ease(.02,.74,-f.z));
 const rollDelta=Math.asin(clamp(up.x,-1,1))*.42*(1-ease(.0,.70,-up.y));
 const corrected=weight=>new THREE.Quaternion().setFromAxisAngle(axisY,yawDelta*weight)
  .multiply(new THREE.Quaternion().setFromAxisAngle(axisX,pitchDelta*weight))
  .multiply(authored).multiply(new THREE.Quaternion().setFromAxisAngle(axisZ,rollDelta*weight));
 const minY=q=>{
  const world=parent.clone().multiply(q);
  return Math.min(...soleChecks.map(v=>v.clone().applyQuaternion(world).y));
 };
 const freeY=minY(corrected(1)),authoredY=minY(authored),clearance=ankleY+freeY;
 lock=Math.max(lock,(1-ease(-.026,.012,clearance))*ease(.001,.028,authoredY-freeY));
 return corrected((1-lock)*correctionScale);
}
function gripFor(state,index){
 const speed=state.speed||0;
 return clamp(state.handGrip?.[index]??state.grip??(state.armPose==='slide'?.14:lerp(.18,.46,ease(.75,6.4,speed))));
}
function poseHand(p,state,index,ground,extension){
 const wrist=p.wrists[index],evidence=state.evidenceHands??0;
 const grip=lerp(lerp(gripFor(state,index),state.grip??gripFor(state,index),evidence),.09,ground*.94);
 const spread=lerp(state.handSpread?.[index]??.18,.54,ground);
 const grasp=state.handTargets?.[index]
  ? Math.max(0,(grip-.72)/.28)*.42*(state.handWeight??1):0;
 const pitch=(state.wristPitch?.[index]??-.08)+grasp;
 const yaw=state.wristYaw?.[index]??0;
 const roll=state.wristRoll?.[index]??0;
 wrist.rotation.set(lerp(lerp(softLimit(pitch,-1.04,.82,.14),extension,ground),pitch,evidence),
  lerp(softLimit(yaw*.15,-.23,.23,.07),0,Math.max(ground,evidence)),
  lerp(lerp(softLimit(roll,-.42,.42,.08),0,ground),roll,evidence));
 for(const [i,finger] of p.digits[index].entries()){
  const curl=finger.thumb?.54:[.72,.80,.87,.94][i];
  const fan=(i-1.5)*.11*spread;
  const root=finger.b,tip=finger.distal;
  const delta=new THREE.Quaternion().setFromEuler(new THREE.Euler(
    (i*.026+.04)+grip*curl,finger.thumb?finger.side*.13*spread:0,
    finger.thumb?-finger.side*.17*spread:fan));
  root.quaternion.copy(finger.bind).multiply(delta);
  tip.quaternion.copy(finger.distalBind).multiply(new THREE.Quaternion().setFromAxisAngle(axisX,
    .025 + grip*(finger.thumb?.70:1.00+i*.035)));
  if(evidence){
   const b=new THREE.Euler().setFromQuaternion(finger.bind);
   const d=new THREE.Euler().setFromQuaternion(finger.distalBind);
   b.x+=(state.grip??grip)*(finger.thumb?.60:.68);d.x+=(state.grip??grip)*.94;
   root.quaternion.slerp(new THREE.Quaternion().setFromEuler(b),evidence);
   tip.quaternion.slerp(new THREE.Quaternion().setFromEuler(d),evidence);
  }
 }
}
// The mesh's palm is local -Z. Choose where the palm points using the
// ribcage and the moving forearm, then roll around the forearm's long axis.
// A wrist bend alone cannot rotate the palm into a running or balance pose.
function palmTurn(p,state,index,chestQ,foreQ){
 const side=index===0?-1:1;
 const intent=state.wristYaw?.[index]??0;
 const chestInverse=chestQ.clone().invert();
 const armAxis=DOWN.clone().applyQuaternion(p.arms[index].getWorldQuaternion(new THREE.Quaternion())).applyQuaternion(chestInverse);
 const forward=ease(-.47,.55,armAxis.z);
 const grip=gripFor(state,index),spread=state.handSpread?.[index]??.18;
 const reach=ease(.14,.42,spread)*(1-ease(.44,.72,grip));
 const held=state.handTargets?state.handWeight??1:0;
 const lateral=lerp(.92,.60,Math.max(reach,forward*.74))*(-side);
 const down=-.11-.54*forward-.29*reach;
 const facing=lerp(-.44,.23,forward)-.16*reach;
 const desired=new V(lateral,down,facing).applyQuaternion(chestQ).applyQuaternion(foreQ.clone().invert());
 const projected=Math.hypot(desired.x,desired.z);
 // Pick the continuous anatomical arc for each hand. When the forearm
 // points almost along the goal vector the roll is intentionally soft.
 const arc=Math.atan2(Math.max(.035,-side*desired.x),-desired.z)*side;
 const spin=softLimit(arc+intent*.26,-1.58,1.58,.24);
 const neutral=softLimit(intent*.76,-.75,.75,.16);
 const amount=ease(.12,.46,projected)*lerp(.68,.91,forward)*(1-ease(.015,.38,held));
 return lerp(neutral,spin,amount)*(1-(state.evidenceHands??0));
}
function solveArm(p,index,target,hint,weight,ground,evidence){
 const arm=p.arms[index],elbow=p.elbows[index],a=arm.quaternion.clone(),b=elbow.quaternion.clone(),hip=arm.position.clone(),local=p.chest.worldToLocal(new V(...target)),delta=local.clone().sub(hip),fore=lerp(.275,.245,ground),length=Math.min(.29+fore-.001,Math.max(.049,delta.length())),direction=delta.normalize(),along=(.29*.29-fore*fore+length*length)/(2*length),height=Math.sqrt(Math.max(0,.29*.29-along*along));
 let pole=p.chest.worldToLocal(new V(...hint)).sub(hip);pole.addScaledVector(direction,-pole.dot(direction));if(pole.lengthSq()<1e-12){pole=new V(index===0?-1:1,0,-1);pole.addScaledVector(direction,-pole.dot(direction));}
 pole.normalize();const knee=hip.clone().addScaledVector(direction,along).addScaledVector(pole,height),end=hip.clone().addScaledVector(direction,length);
 const upper=knee.clone().sub(hip).normalize(),lower=end.clone().sub(knee).normalize();
 const hinge=new V().crossVectors(direction,pole).normalize();
 const ik=limbFrame(upper,hinge),foreIK=new THREE.Quaternion().setFromAxisAngle(axisX,-upper.angleTo(lower));
 if(evidence>0){
  const original=new THREE.Quaternion().setFromUnitVectors(DOWN,upper);
  const oldFore=new THREE.Quaternion().setFromUnitVectors(DOWN,lower.clone().applyQuaternion(original.clone().invert()));
  ik.slerp(original,evidence);foreIK.slerp(oldFore,evidence);
 }
 arm.quaternion.copy(a.slerp(ik,weight));elbow.quaternion.copy(b.slerp(foreIK,weight));
}
// Redistribute the bend into the spine during get-up. Pivoting at the hip
// sockets keeps the planted boot and the solved knee positions in place.
function unfoldPelvis(p,angle){
 if(!angle)return;
 const pivot=new V(0,-.03,0),before=p.body.quaternion.clone();
 const adjust=new THREE.Quaternion().setFromAxisAngle(axisX,-angle);
 const after=before.clone().multiply(adjust);
 p.body.position.add(pivot.clone().applyQuaternion(before)).sub(pivot.clone().applyQuaternion(after));
 p.body.quaternion.copy(after);
 const inverse=adjust.invert();
 for(const leg of p.legs)leg.quaternion.premultiply(inverse);
 p.spine.position.sub(pivot).applyQuaternion(inverse).add(pivot);
 p.spine.quaternion.premultiply(inverse);
}
export function poseFootballer(p,state){
 p.spine.position.set(0,.18,0);
 p.group.position.set(state.hip[0],0,state.hip[2]);p.group.rotation.y=state.yaw??(state.heading>0?Math.PI/2:-Math.PI/2);p.body.position.set(0,state.hip[1],0);p.body.rotation.set(state.lean||0,state.pelvisYaw||0,state.roll||0);p.spine.rotation.set(state.spinePitch||0,state.spineYaw??state.twist??0,state.spineRoll||0);p.chest.rotation.set(state.chestPitch||0,state.chestYaw??-(state.twist||0)*.35,state.chestRoll||0);p.headPivot.rotation.set(state.headPitch??(state.armPose==='kick'?.13:-.025),state.headYaw??state.headTurn??0,state.headRoll||0);p.group.updateMatrixWorld(true);
 const pain=state.pain||0,effort=Math.min(1,(state.speed||0)/7.2),clock=((state.time||0)+p.number*.173)%4.2,blink=Math.sin(Math.min(1,Math.max(0,(clock-3.94)/.18))*Math.PI)**2;
 p.jaw.rotation.x=pain*.09+effort*.018;p.brows.forEach((b,i)=>{b.rotation.z=(i?1:-1)*(.015+pain*.20);b.position.y=.110-pain*.005;});p.lids.forEach(l=>{l.position.y=.095-(blink+pain*.25)*.007;l.scale.y=1+blink*.9+pain*.25;});
 p.maxReachError=0;
 for(let i=0;i<2;i++)p.maxReachError=Math.max(p.maxReachError,solveLeg(p,i,state.feet[i],state.kneeHints?.[i]));
 p.group.updateMatrixWorld(true);
 for(let i=0;i<2;i++)poseBoot(p,i,state);
 const swing=Math.sin(state.armPhase||0)*(state.armSwing??.38);
 p.arms.forEach((a,i)=>{a.rotation.set((i?1:-1)*swing,0,(i===0?1:-1)*.09);p.elbows[i].rotation.set(-(state.elbowFlex?.[i]??state.elbow??.35),0,0);});
 if(state.armPose==='kick'){p.arms[0].rotation.set(.25,0,-.60);p.arms[1].rotation.set(-.36,0,.42);p.elbows[0].rotation.x=-.5;p.elbows[1].rotation.x=-.8;}
 if(state.kickWeight){const w=state.kickWeight;[[.25,0,-.60],[-.36,0,.42]].forEach((r,i)=>{p.arms[i].quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(...r)),w);p.elbows[i].quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(i?-.8:-.5,0,0)),w);});}
 if(state.armPose==='brace'){p.arms[0].rotation.set(-1.25,0,.5);p.arms[1].rotation.set(-1.35,0,-.4);p.elbows.forEach(a=>a.rotation.x=-.15);}
 if(state.armPose==='slide'){p.arms[0].rotation.set(-.65,0,.55);p.arms[1].rotation.set(.5,0,-.48);}
 if(state.armPose==='card'){p.arms[1].rotation.set(-2.9,0,-.15);p.elbows[1].rotation.x=-.05;p.arms[0].rotation.set(-.25,0,.22);}
 if(state.armPose==='save'){p.arms[0].rotation.set(-1.8,0,.65);p.arms[1].rotation.set(-1.8,0,-.65);p.elbows.forEach(a=>a.rotation.x=-.12);}
 if(state.armPose==='whistle'){p.arms[1].rotation.set(-1.45,0,-.2);p.elbows[1].rotation.x=-1.3;p.arms[0].rotation.set(-1.85,0,.25);}
 if(state.armRotations){p.arms.forEach((arm,i)=>arm.rotation.set(...state.armRotations[i]));p.elbows.forEach((elbow,i)=>elbow.rotation.set(state.elbowAngles[i],0,0));}
 if(state.gesture){const gestures={appeal:[[-.5,0,.68],[-.68,0,-.55]],acknowledge:[[.25,0,.45],[-1.25,0,-.26]],whistle:[[-.25,0,.18],[-1.45,0,-.2]],observe:[[-.18,0,.12],[-.20,0,-.12]],ready:[[-.35,0,.20],[-.35,0,-.20]]},pose=gestures[state.gesture]||gestures.observe,w=state.gestureWeight??1;pose.forEach((r,i)=>{p.arms[i].quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(...r)),w);p.elbows[i].quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(state.gesture==='whistle'&&i===1?-1.3:-.85,0,0)),w);});}
 const grounds=[0,1].map(i=>clamp((state.handGroundWeight?.[i]??(state.handGround?.[i]||state.armPose==='slide'&&i===1?1:0))*(state.handWeight??1)));
 if(state.handTargets){p.group.updateMatrixWorld(true);for(let i=0;i<2;i++){
  solveArm(p,i,state.handTargets[i],state.elbowHints[i],state.handWeight??1,grounds[i],state.evidenceHands??0);
 }}
 const chestQ=p.chest.getWorldQuaternion(new THREE.Quaternion());
 for(let i=0;i<2;i++){
  const ground=grounds[i],fore=p.elbows[i];
  let extension=-.81;
  const foreQ=fore.getWorldQuaternion(new THREE.Quaternion());
  let pronation=palmTurn(p,state,i,chestQ,foreQ);
  if(ground>0){
   const up=axisY.clone().applyQuaternion(foreQ.clone().invert());
   // Aim the palm down by rolling the forearm and extending the wrist
   // in its own axes, avoiding a shortest-path flip across 180 degrees.
   const rise=ease(.025,.35,Math.hypot(up.x,up.z));
   const turn=softLimit(up.x*2.1,-1.22,1.22,.19)*rise;
   pronation=lerp(pronation,turn,ground);
   extension=softLimit(-Math.asin(clamp(up.y,-1,1)),-1.16,.23,.16);
  }
  fore.rotateY(pronation);
  poseHand(p,state,i,ground,extension);
 }
 unfoldPelvis(p,state.pelvisUnfold);
 p.group.updateMatrixWorld(true);updateClothContacts(p,state);
}
export function animateRunner(p,x,z,t,run=1,dir=1,fall=0){
 const speed=run*2.8,path=linearPath(x-speed*dir*t,z,speed*dir,0),state=sampleLocomotion(path,t,{pace:Math.max(.7,speed),phase:p.number*.13});
 if(fall){state.hip[1]-=fall*.55;state.lean+=fall*1.1;state.armPose='brace';state.armRotations=undefined;state.elbowAngles=undefined;}poseFootballer(p,state);
}
