import {BALL_RADIUS,passTrack,looseBallTrack,createBallTrack} from './ball-physics.mjs';
import {sampleAuthoredGait,sampleAuthoredSwing} from './locomotion-library.mjs';
import {cadenceProfile,gaitTiming,pathSpeed} from './gait-clock.mjs';
import {sampleKickReference} from './kick-reference.mjs';
// Pure, time-addressable football motion. The same poses drive live play and VAR.
export const SHOULDER_LOCAL_Y=.105;
export {BALL_RADIUS} from './ball-physics.mjs';
export const BOOT_TOE=.245,GROUND_FOOT=.094;
export const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const lerp=(a,b,q)=>a+(b-a)*q;
export const smooth=(a,b,v)=>{const q=clamp((v-a)/(b-a));return q*q*(3-2*q);};
export const ease=(a,b,v)=>{const q=clamp((v-a)/(b-a));return q*q*q*(10+q*(-15+6*q));};
export const softMin=(a,b,r=.014)=>(a+b-Math.sqrt((a-b)**2+r*r))*.5;
export const recoil=(t,amplitude=1,decay=.20,period=.32)=>t<=0?0:amplitude*(1-Math.exp(-t/.028))**3*Math.exp(-t/decay)*Math.sin(t*Math.PI*2/period);
export const vecLerp=(a,b,q)=>a.map((v,i)=>lerp(v,b[i],q));
const fract=v=>v-Math.floor(v);
const hermite=(a,b,da,db,q)=>{const gap=b-a,c3=10*gap-6*da-4*db,c4=-15*gap+8*da+7*db,c5=6*gap-3*da-3*db;return a+da*q+c3*q**3+c4*q**4+c5*q**5;};
export const yawFor=(dx,dz)=>Math.atan2(dx,dz);
export function localPoint(root,yaw,forward,height,lateral=0){return [root[0]+Math.sin(yaw)*forward-Math.cos(yaw)*lateral,height,root[1]+Math.cos(yaw)*forward+Math.sin(yaw)*lateral];}
export const linearPath=(x,z,vx,vz)=>t=>[x+vx*t,z+vz*t];
const add3=(a,b)=>a.map((v,i)=>v+b[i]);
function rotate3(v,[x=0,y=0,z=0]){const cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y),cz=Math.cos(z),sz=Math.sin(z),a=v[0]*cz-v[1]*sz,b=v[0]*sz+v[1]*cz,c=a*cy+v[2]*sy,d=-a*sy+v[2]*cy;return [c,b*cx-d*sx,b*sx+d*cx];}
// Resolve complete arm channels before blending. Semantic pose labels must not
// switch the rendered joints halfway through a transition.
export function resolveArms(s){
 const swing=Math.sin(s.armPhase||0)*(s.armSwing??.38),arms=s.armRotations?s.armRotations.map(a=>a.slice()):[[swing,0,.09],[-swing,0,-.09]],elbows=s.elbowAngles?s.elbowAngles.slice():[0,1].map(i=>-(s.elbowFlex?.[i]??s.elbow??.35));
 const overlay=(poses,angles,w)=>{for(let i=0;i<2;i++){arms[i]=vecLerp(arms[i],poses[i],w);elbows[i]=lerp(elbows[i],angles[i],w);}};
 const preset={kick:[[[.25,0,-.60],[-.36,0,.42]],[-.5,-.8]],brace:[[[-1.25,0,.5],[-1.35,0,-.4]],[-.15,-.15]],slide:[[[-.65,0,.55],[.5,0,-.48]],[-1.1,-1.1]],card:[[[-.25,0,.22],[-2.9,0,-.15]],[-.35,-.05]],save:[[[-1.8,0,.65],[-1.8,0,-.65]],[-.12,-.12]],whistle:[[[-1.85,0,.25],[-1.45,0,-.2]],[-.35,-1.3]]};
 if(!s.armRotations){if(preset[s.armPose])overlay(...preset[s.armPose],1);if(s.kickWeight)overlay(...preset.kick,s.kickWeight);}
 const gestures={appeal:[[-.5,0,.68],[-.68,0,-.55]],acknowledge:[[.25,0,.45],[-1.25,0,-.26]],whistle:[[-.25,0,.18],[-1.45,0,-.2]],observe:[[-.18,0,.12],[-.20,0,-.12]],ready:[[-.35,0,.20],[-.35,0,-.20]]};
 if(s.gesture)overlay(gestures[s.gesture]||gestures.observe,[-.85,s.gesture==='whistle'?-1.3:-.85],s.gestureWeight??1);
 return {arms,elbows};
}
function handFK(s,i,elbow=false){const r=resolveArms(s),fore=add3([0,-.29,0],elbow?[0,0,0]:rotate3([0,-.275,.01],[r.elbows[i],0,0])),chest=add3([(i?1:-1)*.226,SHOULDER_LOCAL_Y,0],rotate3(fore,r.arms[i])),spine=add3([0,.23,0],rotate3(chest,[s.chestPitch||0,s.chestYaw??-(s.twist||0)*.35,s.chestRoll||0])),body=add3([0,.18,0],rotate3(spine,[s.spinePitch||0,s.spineYaw??s.twist??0,s.spineRoll||0])),local=rotate3(body,[s.lean||0,s.pelvisYaw||0,s.roll||0]),world=rotate3(local,[0,s.yaw??s.heading*Math.PI/2,0]);return add3(s.hip,world);}
// Shared by transitions and the rendered joint constraints.
export function bootConstraint(s,i){
 if(s.bootContact?.[i]!==undefined)return clamp(s.bootContact[i]);
 if(s.phases&&s.footStance&&s.slide===undefined&&s.fall===undefined){
  const phase=s.phases[i],stance=s.footStance[i];
  return Math.max(1-ease(stance,stance+.13,phase),ease(.90,1,phase));
 }
 return 1-ease(.12,.22,s.feet[i][1]);
}
const gripOf=(s,i)=>s.handGrip?.[i]??s.grip??(s.armPose==='slide'?.14:lerp(.18,.46,ease(.75,6.4,s.speed||0)));
const groundHands=s=>s.handGroundWeight||[0,1].map(i=>s.handGround?.[i]?1:s.armPose==='slide'&&i===1?1:0);
export function blendPose(a,b,q){
 const dy=Math.atan2(Math.sin((b.yaw??b.heading*Math.PI/2)-(a.yaw??a.heading*Math.PI/2)),Math.cos((b.yaw??b.heading*Math.PI/2)-(a.yaw??a.heading*Math.PI/2)));
 const result={...(q<.5?a:b),hip:vecLerp(a.hip,b.hip,q),feet:a.feet.map((v,i)=>vecLerp(v,b.feet[i],q)),yaw:(a.yaw??a.heading*Math.PI/2)+dy*q,lean:lerp(a.lean||0,b.lean||0,q),roll:lerp(a.roll||0,b.roll||0,q),twist:lerp(a.twist||0,b.twist||0,q),armPhase:lerp(a.armPhase||0,b.armPhase||0,q),armSwing:lerp(a.armSwing??.35,b.armSwing??.35,q),footPitch:[0,1].map(i=>lerp(a.footPitch?.[i]||0,b.footPitch?.[i]||0,q))};
 for(const field of ['pelvisYaw','spineYaw','chestYaw','spinePitch','chestPitch','spineRoll','chestRoll','headPitch','headYaw','headRoll','handWeight','kickWeight','gestureWeight','pain','grip'])result[field]=lerp(a[field]||0,b[field]||0,q);
 result.footYaw=[0,1].map(i=>lerp(a.footYaw?.[i]||0,b.footYaw?.[i]||0,q));result.footRoll=[0,1].map(i=>lerp(a.footRoll?.[i]||0,b.footRoll?.[i]||0,q));
 if(a.kneeHints||b.kneeHints)result.kneeHints=[0,1].map(i=>vecLerp(a.kneeHints?.[i]||localPoint([a.hip[0],a.hip[2]],a.yaw??a.heading*Math.PI/2,.75,a.hip[1],i===0?.1:-.1),b.kneeHints?.[i]||localPoint([b.hip[0],b.hip[2]],b.yaw??b.heading*Math.PI/2,.75,b.hip[1],i===0?.1:-.1),q));
 if(a.handTargets||b.handTargets){result.handTargets=[0,1].map(i=>vecLerp(a.handTargets?.[i]||handFK(a,i),b.handTargets?.[i]||handFK(b,i),q));result.elbowHints=[0,1].map(i=>vecLerp(a.elbowHints?.[i]||handFK(a,i,true),b.elbowHints?.[i]||handFK(b,i,true),q));result.handWeight=lerp(a.handWeight??(a.handTargets?1:0),b.handWeight??(b.handTargets?1:0),q);}
 const aa=resolveArms(a),bb=resolveArms(b);result.armRotations=aa.arms.map((arm,i)=>vecLerp(arm,bb.arms[i],q));result.elbowAngles=aa.elbows.map((e,i)=>lerp(e,bb.elbows[i],q));result.handGroundWeight=vecLerp(groundHands(a),groundHands(b),q);
 // The gesture is now baked into these arm channels; later callers may add a
 // new whistle or appeal without applying the previous gesture a second time.
 result.gesture=undefined;result.gestureWeight=0;
 result.elbowFlex=[0,1].map(i=>lerp(a.elbowFlex?.[i]??a.elbow??.35,b.elbowFlex?.[i]??b.elbow??.35,q));
 const grip=s=>s.grip??(s.armPose==='slide'?.10:s.speed>6?.65:s.speed>2?.58:.17);result.grip=lerp(grip(a),grip(b),q);
 result.wristPitch=[0,1].map(i=>lerp(a.wristPitch?.[i]??-.08,b.wristPitch?.[i]??-.08,q));result.wristRoll=[0,1].map(i=>lerp(a.wristRoll?.[i]||0,b.wristRoll?.[i]||0,q));
 result.wristYaw=[0,1].map(i=>lerp(a.wristYaw?.[i]||0,b.wristYaw?.[i]||0,q));
 result.handGrip=[0,1].map(i=>lerp(gripOf(a,i),gripOf(b,i),q));
 result.handSpread=[0,1].map(i=>lerp(a.handSpread?.[i]??.18,b.handSpread?.[i]??.18,q));
 if(a.bootContact||b.bootContact)result.bootContact=[0,1].map(i=>lerp(bootConstraint(a,i),bootConstraint(b,i),q));
 if(a.looseBoot||b.looseBoot)result.looseBoot=[0,1].map(i=>lerp(a.looseBoot?.[i]??0,b.looseBoot?.[i]??0,q));
 if(a.pelvisUnfold||b.pelvisUnfold)result.pelvisUnfold=lerp(a.pelvisUnfold||0,b.pelvisUnfold||0,q);
 return result;
}
const HIP_SIDE = .104;
const HIP_DROP = -.03;

function fitPelvisToFeet(pose, reach, softness) {
  const rotation = [pose.lean || 0, pose.pelvisYaw || 0, pose.roll || 0];
  for (let foot = 0; foot < 2; foot++) {
    const hip = rotate3([(foot === 0 ? -1 : 1) * HIP_SIDE, HIP_DROP, 0], rotation);
    const [x, y, z] = rotate3(hip, [0, pose.yaw, 0]);
    const target = pose.feet[foot];
    const horizontal = (target[0] - pose.hip[0] - x) ** 2 + (target[2] - pose.hip[2] - z) ** 2;
    const height = target[1] - y + Math.sqrt(Math.max(.02, reach ** 2 - horizontal));
    pose.hip[1] = softMin(pose.hip[1], height, softness);
  }
  return pose;
}

const shortestAngle = (from, to) => Math.atan2(Math.sin(to - from), Math.cos(to - from));

export function sampleIdle(root, yaw, t = 0) {
  const motion = sampleAuthoredGait('idle', t / 11.66667);
  // Breathing moves the chest. Ankles and hips compensate in place.
  const breath = Math.sin(t * Math.PI / 2.12 + Math.sin(yaw) * .39);
  const weight = Math.sin(t * Math.PI / 3.75 + Math.sin(yaw) * .76);
  const hip = localPoint(root, yaw, .012, .998 + motion.hip * .27, -motion.sway * .58);
  return fitPelvisToFeet({
    hip, yaw, time: t, action: '대기',
    feet: [
      localPoint(root, yaw, .052, GROUND_FOOT, .126),
      localPoint(root, yaw, -.034, GROUND_FOOT, -.112),
    ],
    lean: .017 + motion.body[0] * .29,
    roll: motion.body[2] * .28 - .018 * weight,
    pelvisYaw: motion.body[1] * .46,
    spinePitch: motion.torso[0] * .26 - .004 * breath,
    spineYaw: motion.torso[1] * .22,
    chestPitch: motion.torso[0] * .42 + .012 * breath,
    chestYaw: motion.torso[1] * .45,
    chestRoll: motion.torso[2] * .36 + .012 * weight,
    headPitch: (motion.head[0] - .20) * .30,
    headYaw: motion.head[1] * .40,
    headRoll: motion.head[2] * .30,
    footPitch: [0, 0], footYaw: [-.16, .14],
    armRotations: motion.arms.map((arm, i) => [
      arm[0] * .76,
      arm[1] * .65,
      arm[2] * .68 + (i === 0 ? -.025 : .025),
    ]),
    elbowAngles: motion.elbows.map(angle => angle * .70),
    wristPitch: [-.045 + .018 * breath, -.055 - .012 * breath],
    wristYaw: [-.77 + .035 * weight, .73 + .025 * weight],
    wristRoll: [.035 + .025 * weight, -.03 + .018 * weight],
    handGrip: [.15 + .025 * weight, .19 - .022 * weight],
    handSpread: [.11, .095], grip: .17,
    animationSource: motion.source,
  }, .8765, .006);
}

function blendGait(from, to, amount) {
  if (amount === 0) return from;
  if (amount === 1) return to;
  return {
    source: amount < .5 ? from.source : to.source,
    hip: lerp(from.hip, to.hip, amount),
    sway: lerp(from.sway, to.sway, amount),
    body: vecLerp(from.body, to.body, amount),
    torso: vecLerp(from.torso, to.torso, amount),
    head: vecLerp(from.head, to.head, amount),
    arms: from.arms.map((arm, i) => vecLerp(arm, to.arms[i], amount)),
    elbows: vecLerp(from.elbows, to.elbows, amount),
  };
}

function gaitAt(phase, run, sprint) {
  const jogging = () => sampleAuthoredGait('jog', phase);
  const running = () => sprint === 1 ? sampleAuthoredGait('sprint', phase)
    : sprint === 0 ? jogging()
    : blendGait(jogging(), sampleAuthoredGait('sprint', phase), sprint);
  if (run === 0) return sampleAuthoredGait('walk', phase);
  if (run === 1) return running();
  return blendGait(sampleAuthoredGait('walk', phase), running(), run);
}

function rollBoot(anchor, yaw, heading, pitch, pivotForward, pivotHeight) {
  const pivot = [0, pivotHeight, pivotForward];
  const planted = rotate3(pivot, [0, heading, 0]);
  const tilted = rotate3(rotate3(pivot, [pitch, shortestAngle(yaw, heading), 0]), [0, yaw, 0]);
  return anchor.map((value, axis) => value + planted[axis] - tilted[axis]);
}

function swingSample(index, progress, run, sprint) {
  const sample = kind => sampleAuthoredSwing(kind, index, progress);
  const blend = (a, b, q) => ({pitch: lerp(a.pitch, b.pitch, q), lift: lerp(a.lift, b.lift, q)});
  if (run === 0) return sample('walk');
  const running = sprint === 1 ? sample('sprint') : sprint === 0 ? sample('jog')
    : blend(sample('jog'), sample('sprint'), sprint);
  return run === 1 ? running : blend(sample('walk'), running, run);
}

export function sampleLocomotion(path, t, {pace = null, phase = 0, adaptive = pace === null} = {}) {
  const root = path(t);
  const speed = pathSpeed(path, t);
  const idleYawAt = time => {
    if (typeof path.idleYaw === 'function') return path.idleYaw(time);
    const a = path(time - .35), b = path(time + .35);
    return Math.hypot(b[0] - a[0], b[1] - a[1]) > .015
      ? yawFor(b[0] - a[0], b[1] - a[1]) : 0;
  };
  const headingAt = time => {
    // A 120 ms velocity window keeps pivots continuous through sharp routes.
    const a = path(time - .060), b = path(time + .060);
    const dx = b[0] - a[0], dz = b[1] - a[1];
    const actual = Math.hypot(dx, dz) / .120;
    const direction = yawFor(dx, dz);
    if (actual >= .45) return direction;
    const idle = idleYawAt(time);
    return idle + shortestAngle(idle, direction) * ease(.04, .45, actual);
  };

  const yaw = headingAt(t);
  const profile = adaptive ? cadenceProfile(path, pace) : null;
  const timing = profile ? profile.timingAt(t) : gaitTiming(pace ?? speed);
  const {pace: cadence, run, sprint, period, stance} = timing;
  const timeAt = step => profile ? profile.timeAt(step) : step * period;
  const clock = (profile ? profile.phaseAt(t) : t / period) + phase;
  const phases = [fract(clock), fract(clock + .5)];
  const active = ease(.025, .70, speed);
  const idle = active < 1 ? sampleIdle(root, idleYawAt(t), t) : null;
  if (active === 0) {
    return {...idle, speed, acceleration: 0, turnRate: 0, period, stance, phases, planted: [true, true]};
  }

  const effort = clamp(speed / Math.max(adaptive ? .9 : .05, cadence));
  const drive = ease(.9, 2.7, speed) * run;
  const footPitch = [], footYaw = [], planted = [], footStance = [];

  function stepContact(step, side) {
    const touch = timeAt(step);
    const at = path(touch), yaw = headingAt(touch), speed = pathSpeed(path, touch);
    const style = profile ? profile.timingAt(touch) : timing;
    const drive = ease(.9, 2.7, speed) * style.run;
    // A sprint releases before the advancing hip has to reach back for the boot.
    // Bring the next contact closer as pace rises to avoid a hard reaching step.
    const loadAlong = lerp(.50, .43, drive);
    let stance = style.stance - .060 * drive * style.sprint;
    let fore = speed * style.period * stance * loadAlong;
    let lateral = lerp(.111, .098, drive), turnOffset = 0, anchorYaw = yaw, center = at;
    if (profile) {
      // The inside leg spends longer in contact on a curve. Braking shifts
      // the plant forward and widens the base for changes of direction.
      const turning = shortestAngle(headingAt(touch - .08), headingAt(touch + .08));
      const curve = ease(.02, .25, Math.abs(turning)) * ease(.6, 3, speed);
      const outside = Math.sign(turning) * side;
      const acceleration = (pathSpeed(path, touch + .10) - pathSpeed(path, touch - .10)) / .20;
      const brake = ease(1.2, 5.5, -acceleration) * ease(.75, 2.8, speed);
      const push = ease(1.3, 6, acceleration) * (1 - ease(3.5, 6.4, speed));
      stance += .058 * brake + (outside < 0 ? .042 : -.012) * curve;
      // The first drive step releases as the runner gains speed. A walking
      // contact inherited from rest would pin the trailing ankle too long.
      const releaseSpeed = pathSpeed(path, timeAt(step + stance));
      const launch = ease(.65, 2.6, releaseSpeed - speed) * (1 - ease(.35, 2.2, speed));
      stance -= .205 * launch;
      // Set the boot along the actual path of the hips. A turn can otherwise
      // carry them across a stationary foot placed along the old heading.
      const releaseAt = fraction => path(timeAt(step + fraction));
      let release = releaseAt(stance);
      if (Math.hypot(release[0] - at[0], release[1] - at[1]) > .86) {
        let near = 0, far = stance;
        for (let i = 0; i < 8; i++) {
          const mid = (near + far) * .5;
          const point = releaseAt(mid);
          if (Math.hypot(point[0] - at[0], point[1] - at[1]) > .86) far = mid;
          else near = mid;
        }
        stance = near;
        release = releaseAt(stance);
      }
      const dx = release[0] - at[0], dz = release[1] - at[1];
      center = [lerp(at[0], release[0], loadAlong), lerp(at[1], release[1], loadAlong)];
      anchorYaw = yaw + shortestAngle(yaw, yawFor(dx, dz)) * ease(.08, .55, Math.hypot(dx, dz)) * .66;
      fore = .076 * brake - .09 * push;
      lateral += .035 * brake + (outside > 0 ? .052 : -.021) * curve;
      turnOffset = turning * .25;
    }
    const anchor = localPoint(center, anchorYaw, fore, GROUND_FOOT, side * lateral);
    const heading = yaw - side * lerp(.115, .052, drive) + turnOffset;
    const landingPitch = -lerp(.15, .06 * (1 - style.sprint), drive) * clamp(speed / style.pace);
    return {anchor, heading, landingPitch, lateral: side * lateral, stance};
  }

  const feet = phases.map((supportPhase, index) => {
    const offset = phase + index * .5;
    const step = Math.floor(clock + index * .5) - offset;
    const side = index === 0 ? 1 : -1;
    const from = stepContact(step, side);
    const {anchor, heading: fromHeading, landingPitch: heelPitch, lateral} = from;
    const liftAt = timeAt(step + from.stance);
    const liftSpeed = pathSpeed(path, liftAt);
    const liftStyle = profile ? profile.timingAt(liftAt) : timing;
    const pushPitch = lerp(.30, .42, ease(.9, 2.7, liftSpeed) * liftStyle.run)
      * (.55 + .45 * clamp(liftSpeed / liftStyle.pace));

    footStance.push(from.stance);
    planted.push(supportPhase <= from.stance);
    if (supportPhase <= from.stance) {
      const load = supportPhase / from.stance;
      const landing = heelPitch * (1 - ease(0, .20, load));
      const push = pushPitch * ease(.62, 1, load);
      const pitch = landing + push;
      const pivotForward = load < .3 ? -.055 : .18;
      const pivotHeight = load < .3 ? -.082 : -.06;
      footYaw.push(shortestAngle(yaw, fromHeading));
      footPitch.push(pitch);
      return rollBoot(anchor, yaw, fromHeading, pitch, pivotForward, pivotHeight);
    }

    const to = stepContact(step + 1, side);
    const {anchor: nextAnchor, heading: toHeading, landingPitch: nextPitch} = to;
    const swingTime = timeAt(step + 1) - liftAt;
    const elapsed = t - liftAt;
    const swing = clamp(elapsed / swingTime);
    const swingYaw = fromHeading + shortestAngle(fromHeading, toHeading) * ease(0, 1, swing);
    footYaw.push(shortestAngle(yaw, swingYaw));
    const release = rollBoot(anchor, yaw, fromHeading, pushPitch, .18, -.06);
    const landing = rollBoot(nextAnchor, yaw, toHeading, nextPitch, -.055, -.082);
    // A lifted leg finishes its current step while the body brakes. Changing
    // clips halfway through recovery would send the foot back toward takeoff.
    const swingStyle = profile ? liftStyle : timing;
    const swingDrive = profile ? ease(.9, 2.7, liftSpeed) * liftStyle.run : drive;
    const swingEffort = profile ? clamp(liftSpeed / Math.max(.9, liftStyle.pace)) : effort;
    const source = swingSample(index, swing, swingStyle.run, swingStyle.sprint);
    const sourceWindow = Math.sin(Math.PI * swing) ** 2;
    const pitch = lerp(pushPitch, nextPitch, ease(0, 1, swing));
    footPitch.push(pitch + source.pitch * sourceWindow * lerp(.55, .78, swingDrive));

    const walk = vecLerp(release, landing, ease(0, 1, swing));
    walk[1] += sourceWindow * (.095 + .28 * source.lift) * swingEffort;
    if (swingDrive === 0) return walk;

    // The swing passes under the hip, then the knee drives the next landing.
    // World-space joins have zero ankle velocity at lift-off and touchdown.
    const phases = [.31, lerp(.68, .69, swingStyle.sprint)];
    const firstAt = liftAt + swingTime * phases[0], secondAt = liftAt + swingTime * phases[1];
    const firstYaw = headingAt(firstAt), secondYaw = headingAt(secondAt);
    const tuck = swingSample(index, phases[0], swingStyle.run, swingStyle.sprint);
    const first = localPoint(path(firstAt), firstYaw, lerp(-.285, -.21, swingStyle.sprint),
      lerp(.34, .40, swingStyle.sprint) + tuck.lift * .056, lateral);
    const second = localPoint(path(secondAt), secondYaw, lerp(.17, .14, swingStyle.sprint),
      lerp(.285, .36, swingStyle.sprint), to.lateral);
    const firstVelocity = pathVelocity(path, firstAt);
    firstVelocity[0] += Math.sin(firstYaw) * lerp(1.14, .99, swingStyle.sprint) / swingTime;
    firstVelocity[2] += Math.cos(firstYaw) * lerp(1.14, .99, swingStyle.sprint) / swingTime;
    const secondVelocity = pathVelocity(path, secondAt);
    secondVelocity[1] = -.62 / swingTime;
    const stop = [0, 0, 0];
    let moving;
    if (swing < phases[0]) {
      moving = curve3(release, first, stop, firstVelocity, elapsed, swingTime * phases[0]);
    } else if (swing < phases[1]) {
      moving = curve3(first, second, firstVelocity, secondVelocity,
        elapsed - swingTime * phases[0], swingTime * (phases[1] - phases[0]));
    } else {
      moving = curve3(second, landing, secondVelocity, stop,
        elapsed - swingTime * phases[1], swingTime * (1 - phases[1]));
    }
    return vecLerp(walk, moving, swingDrive);
  });

  // A short upper-body lead keeps the arm behind the same-side foot at contact.
  const motion = gaitAt(clock - .065 * run, run, sprint);
  const past = path(t - .12), future = path(t + .12);
  const acceleration = (Math.hypot(future[0] - root[0], future[1] - root[1])
    - Math.hypot(root[0] - past[0], root[1] - past[1])) / (.12 ** 2);
  const turnRate = shortestAngle(headingAt(t - .06), headingAt(t + .06)) / .12;
  const brake = ease(1.1, 5.2, -acceleration) * ease(.65, 2.8, speed);
  const push = ease(1.4, 5.5, acceleration) * ease(.45, 2.7, speed) * (1 - ease(4.3, 6.5, speed));
  const theta = clock * Math.PI * 2;
  const accelerationLean = clamp(acceleration * .012, -.065, .075) + .052 * push;
  const banking = clamp(-Math.atan2(turnRate * speed, 9.81) * .54, -.21, .21);
  const steer = clamp(turnRate * .07, -.20, .20) * ease(.55, 2.8, speed);
  // Each step loads the pelvis first, then the spine and rib cage yield and
  // extend in succession.
  const stepLoad = 2 * theta;
  const loadHip = Math.cos(stepLoad - .43) * lerp(.005, .009 + .002 * sprint, drive);
  const loadSpine = Math.cos(stepLoad - .87) * lerp(.010, .017 + .002 * sprint, drive);
  const loadChest = Math.cos(stepLoad - 1.32) * lerp(.016, .041 + .015 * sprint, drive);
  const transfer = Math.sin(theta - .38) * lerp(.010, .022, drive);
  const upcoming = shortestAngle(headingAt(t + .01), headingAt(t + .20));
  const turnLead = .125 * Math.tanh(upcoming * 3.4) * ease(.65, 3.4, speed);
  const turnBank = -turnLead * .36;
  const steadyLean = lerp(.027, .195 + .054 * sprint, drive) + motion.hip * .19 + accelerationLean;
  const lean = steadyLean + loadHip + .025 * push;
  const roll = motion.body[2] * lerp(.42, .36, drive) + banking + transfer * .52;
  const pelvisYaw = motion.body[1] * lerp(.90, .58, drive) - motion.torso[1] * .63 * drive + steer * .25;
  const spinePitch = motion.torso[0] * .19 + .05 * brake + loadSpine + .041 * push;
  const chestPitch = motion.torso[0] * .14 + .035 * brake + loadChest + .036 * push;
  const hip = localPoint(root, yaw, -.047 * brake,
    lerp(.973, .944, drive) + motion.hip * lerp(.67, .48, drive) - .057 * brake - .018 * push,
    -motion.sway * .72 + banking * .13);
  // The front hand turns slightly inward as the other hand relaxes behind the hip.
  const forearmBeat = [Math.sin(theta - .72), -Math.sin(theta - .72)];
  const gait = fitPelvisToFeet({
    hip, yaw, feet, footPitch, footYaw, lean, roll, pelvisYaw, spinePitch, chestPitch,
    spineYaw: motion.torso[1] * lerp(.34, .46, drive) + steer * .28 + turnLead * .40,
    chestYaw: motion.torso[1] * lerp(.58, .81, drive) + steer * .50 + turnLead * .60,
    spineRoll: motion.torso[2] * .19 - banking * .30 - transfer * .70 + turnBank * .45,
    chestRoll: motion.torso[2] * .38 - banking * .24 - transfer * .88 + turnBank * .55,
    headPitch: clamp(motion.head[0] * .47 - steadyLean * .82
      - .83 * (loadHip + loadSpine + loadChest) - .083 * push, -.43, .22),
    headYaw: motion.head[1] * .46 + clamp(steer * 1.20, -.25, .25) - .68 * turnLead,
    headRoll: motion.head[2] * .26 - banking * .30 + .82 * transfer - .70 * turnBank,
    armRotations: motion.arms.map((arm, index) => {
      const side = index === 0 ? -1 : 1;
      const outside = clamp(side * banking / .21);
      return [
        arm[0] * lerp(.88, 1.08, drive) + .05 * drive - .16 * brake,
        arm[1] * .86,
        arm[2] * .82 + side * (.022 + .14 * outside + .065 * brake),
      ];
    }),
    elbowAngles: motion.elbows,
    wristPitch: forearmBeat.map(beat => -.065 + lerp(.028, .078, drive) * beat - .04 * brake),
    wristYaw: forearmBeat.map((beat, index) => (index === 0 ? -1 : 1) *
      (lerp(.67, .57, drive) + beat * lerp(.06, .12, drive) - .08 * brake)),
    wristRoll: forearmBeat.map((beat, index) => (index === 0 ? 1 : -1) * (.036 + .056 * beat)),
    handGrip: forearmBeat.map(beat => lerp(.21, .43, drive) + beat * (.024 + .063 * drive) - .09 * brake),
    handSpread: forearmBeat.map(beat => lerp(.09, .06, drive) + .03 * (1 - beat) + .10 * brake),
    grip: lerp(.21, .43, drive),
    animationSource: motion.source,
    armPhase: theta - Math.PI / 2, armSwing: lerp(.30, .64, drive),
    speed, acceleration, turnRate, period, stance, footStance, phases, planted, time: t,
    load: Math.exp(5 * (Math.cos(theta * 2 - .55) - 1)),
    action: speed > 6 ? '스프린트' : speed > 2.05 ? '달리기' : '걷기',
  }, lerp(.876, .871, drive), lerp(.018, .036, drive));

  if (active === 1) return gait;
  const blended = blendPose(idle, gait, active);
  return {...blended, speed, acceleration, turnRate, period, stance, footStance, phases, planted};
}


// Slide sequencing follows FIFA's Paredes example: watch the ball, load the
// supporting foot, then reach with the other leg and absorb the follow-through.
function recoveryStep(from, to, progress, lift) {
  const foot = vecLerp(from, to, progress);
  foot[1] += lift * 4 * progress * (1 - progress);
  return foot;
}

// The planted boot and palm share fixed world targets while the hips pass over
// them. Only the trailing boot moves when the player pushes up into standing.
// Account for the depth of the skinned palm and curled fingertips below the
// wrist target. Fade the correction as the support hand lifts from the turf.
function fitGroundPalmClearance(pose, lifts) {
  if (!pose.handTargets || !pose.handGroundWeight) return pose;
  pose.handTargets = pose.handTargets.map(([x, y, z], i) => {
    const weight = pose.handGroundWeight[i] || 0;
    return [x, y + lifts[i] * weight * (2 - weight), z];
  });
  return pose;
}

// Drive an unweighted leg from its hip and knee angles. The ankle follows
// those joints, instead of forcing the hip to reach a target on the turf.
function releaseLeg(pose,index,weight,hipFlex,spread,kneeFlex,minAnkleY=0) {
  if(weight<=0)return;
  const side=index===0?-1:1;
  const thigh=[side*Math.sin(spread),-Math.cos(spread)*Math.cos(hipFlex),Math.cos(spread)*Math.sin(hipFlex)];
  const shin=[side*Math.sin(spread)*Math.cos(kneeFlex),
    thigh[1]*Math.cos(kneeFlex)-Math.sin(hipFlex)*Math.sin(kneeFlex),
    thigh[2]*Math.cos(kneeFlex)-Math.cos(hipFlex)*Math.sin(kneeFlex)];
  const socket=[side*HIP_SIDE,HIP_DROP,0];
  const knee=add3(socket,thigh.map(v=>v*.45));
  const ankle=add3(knee,shin.map(v=>v*.43));
  const world=point=>add3(pose.hip,rotate3(rotate3(point,
    [pose.lean||0,pose.pelvisYaw||0,pose.roll||0]),[0,pose.yaw,0]));
  const ankleTarget=world(ankle);
  if(minAnkleY>0)ankleTarget[1]=-softMin(-ankleTarget[1],-minAnkleY,.018);
  pose.feet[index]=vecLerp(pose.feet[index],ankleTarget,weight);
  pose.kneeHints[index]=vecLerp(pose.kneeHints[index],world(knee),weight);
}

function riseFromTurf(base, root, yaw, time, elapsed, timing, options) {
  const { gather, plant, stand } = timing;
  const { supportHand, look, gesture, pain = 0 } = options;
  const grounded = localPoint(root, yaw, .21, 0);
  const standing = sampleIdle([grounded[0], grounded[2]], yaw, time);
  standing.headYaw = look;
  standing.gesture = gesture;
  standing.gestureWeight = ease(stand - .24, stand + .24, elapsed);
  standing.pain = pain;
  standing.action = gesture === 'observe' ? '일어나 공을 찾기' : '일어나 주심 확인';

  const kneel = sampleIdle(root, yaw, time);
  kneel.hip[1] = .40;
  kneel.lean = 1.18;
  kneel.spinePitch = .15;
  kneel.chestPitch = .10;
  kneel.pelvisUnfold = .83;
  kneel.headPitch = -.32;
  kneel.roll = supportHand ? -.08 : .08;
  kneel.feet = [standing.feet[0].slice(), localPoint(root, yaw, -.37, .112, -.16)];
  kneel.looseBoot = [0, 1];
  kneel.kneeHints = [
    localPoint(root, yaw, .32, .33, .16),
    localPoint(root, yaw, .035, .12, -.18),
  ];
  const side = supportHand ? -.27 : .28;
  const plantedPalm = localPoint(root, yaw, .53, .038, side);
  kneel.handTargets = [localPoint(root, yaw, .28, .39, .29), localPoint(root, yaw, .25, .39, -.28)];
  kneel.handTargets[supportHand] = plantedPalm;
  kneel.elbowHints = [localPoint(root, yaw, .40, .41, .46), localPoint(root, yaw, .40, .41, -.46)];
  kneel.elbowHints[supportHand] = localPoint(root, yaw, .49, .31, side * 1.3);
  kneel.handWeight = 1;
  kneel.handGroundWeight = [0, 1].map(i => i === supportHand ? 1 : 0);
  kneel.handGrip = [0, 1].map(i => i === supportHand ? .06 : .31);
  kneel.handSpread = [0, 1].map(i => i === supportHand ? .35 : .08);
  kneel.wristPitch = [-.10, -.10];
  kneel.headYaw = look * .5;
  kneel.pain = pain;
  kneel.action = '손과 앞발을 짚고 무릎 세우기';

  const gatherWeight = ease(gather, plant, elapsed);
  const rise = ease(plant, stand, elapsed);
  const front = ease(gather, plant - .09, elapsed);
  const rear = ease(plant + .13, stand - .04, elapsed);
  let pose = blendPose(base, kneel, gatherWeight);
  if (rise > 0) pose = blendPose(pose, standing, rise);
  const hipFirst=ease(gather,gather+.105,elapsed)*(1-ease(gather+.23,plant,elapsed));
  pose.pelvisUnfold=(pose.pelvisUnfold||0)+.48*hipFirst;
  pose.feet[0] = recoveryStep(base.feet[0], standing.feet[0], front, .075);
  pose.feet[1] = rear > 0
    ? recoveryStep(kneel.feet[1], standing.feet[1], rear, .095)
    : recoveryStep(base.feet[1], kneel.feet[1], gatherWeight, .036);
  pose.footPitch[0] = lerp(base.footPitch?.[0] || 0, 0, front);
  pose.footPitch[1] = lerp(base.footPitch?.[1] || 0, 0, gatherWeight);
  pose.footYaw[0] = lerp(base.footYaw?.[0] || 0, standing.footYaw[0], front);
  pose.bootContact = [
    Math.max(base.bootContact?.[0] || 0, front),
    Math.max((base.bootContact?.[1] || 0) * (1 - gatherWeight), ease(.75, 1, rear)),
  ];
  pose.looseBoot = [lerp(base.looseBoot?.[0]??0,0,front),lerp(base.looseBoot?.[1]??0,1,gatherWeight)];
  if (elapsed >= plant && rise < 1) {
    // Release the hand as the load transfers from the palm to the front boot.
    const release = ease(plant + .035, plant + .29, elapsed);
    pose.handTargets[supportHand] = vecLerp(plantedPalm, handFK(standing, supportHand), release);
    pose.handGroundWeight[supportHand] = 1 - release;
    pose.handWeight = 1 - ease(plant + .11, stand - .08, elapsed);
    pose.action = '앞발에 체중을 싣고 밀어 일어나기';
  }
  return pose;
}

export function sampleSlideTackle(contact, yaw, t, contactTime, { pitch = 0, reaction = 'careless' } = {}) {
  const elapsed = t - contactTime;
  const height = contact[1];
  const toeFore = -BOOT_TOE * Math.cos(pitch);
  const ankleY = height + BOOT_TOE * Math.sin(pitch);
  const finalRoll = -1.15, finalLean = -.12;
  const hipY = .277;
  const lateral = -.24;
  const hipOffset = rotate3([-.104, -.03, 0], [finalLean, 0, finalRoll]);
  const dy = ankleY - (hipY + hipOffset[1]);
  const dl = -(lateral - hipOffset[0]);
  const reach = Math.sqrt(.865 ** 2 - dy ** 2 - dl ** 2);
  const contactFore = toeFore - reach - hipOffset[2];
  const origin = [contact[0], contact[2]];
  const path = time => {
    const u = time - contactTime;
    const travel = u < 0 ? 4.4 * u : .56 * (1 - Math.exp(-u * 4.4 / .56));
    const drift = lateral + .90 * (1 - smooth(-.8, -.04, u));
    const point = localPoint(origin, yaw, contactFore + travel, 0, drift);
    return [point[0], point[2]];
  };
  const run = sampleLocomotion(path, t, { pace: 4.4, phase: .08 });

  const root = path(t);
  const load = ease(-.58, -.31, elapsed);
  const lower = ease(-.37, -.055, elapsed);
  const extend = ease(-.35, -.015, elapsed);
  const turn = ease(-.26, -.025, elapsed);
  const retract = ease(.105, .48, elapsed);
  const hipHeight = lerp(lerp(run.hip[1], .66, load), hipY, lower);
  const leading = localPoint(
    root, yaw,
    lerp(.07, toeFore - contactFore, extend) - .28 * retract,
    lerp(lerp(GROUND_FOOT, ankleY, smooth(-.25, 0, elapsed)), .117, retract),
    lerp(.105, -lateral, extend) - .036 * retract,
  );
  const pushFoot = localPoint(path(contactTime - .31), yaw, .12, GROUND_FOOT, -.16);
  const rearLift = .025 * ease(-.22, -.19, elapsed) * (1 - ease(-.18, 0, elapsed));
  const trailing = localPoint(root, yaw, -.24 + .105 * retract, .115 + rearLift, -.20);
  const support = ease(-.49, -.31, elapsed) * (1 - ease(-.22, -.18, elapsed));
  const supportHandRoot = path(contactTime + Math.min(Math.max(elapsed, 0), .27));
  const palmRoot = vecLerp(root, supportHandRoot, ease(.05, .27, elapsed));
  const brace = ease(.02, .19, elapsed);
  const palmOnTurf = ease(.025, .14, elapsed) * (1 - ease(.36, .52, elapsed));
  const pose = {
    hip: [root[0], hipHeight, root[1]], yaw,
    feet: [leading, vecLerp(trailing, pushFoot, support)],
    footPitch: [pitch * smooth(-.25, 0, elapsed) * (1 - retract), -.18 * lower * (1 - support)],
    footYaw: [0, -.11 * support],
    bootContact: [ease(-.055, -.012, elapsed) * (1 - ease(.035, .12, elapsed)), support],
    looseBoot: [ease(.035,.19,elapsed),ease(-.229,.035,elapsed)],
    lean: lerp(run.lean, finalLean, lower),
    roll: finalRoll * turn + recoil(elapsed - .015, -.035, .20, .32),
    spineRoll: .12 * turn,
    chestRoll: .12 * turn,
    spinePitch: .08 * lower + recoil(elapsed - .025, .085, .22, .36),
    chestPitch: recoil(elapsed - .060, -.07, .24, .36),
    armPose: 'slide', slide: lower, armPhase: run.armPhase, armSwing: .3, elbow: 1.1,
    kneeHints: [
      localPoint(root, yaw, .42, hipHeight + .21, .12),
      localPoint(root, yaw, .63, lerp(.64, .18, ease(-.22, -.035, elapsed)), -.52),
    ],
    handTargets: [
      localPoint(root, yaw, .16 + .10 * brace, hipHeight + .47 - .06 * brace, .35 - .40 * turn + .07 * brace),
      localPoint(palmRoot, yaw, -.31, lerp(.115, .037, palmOnTurf), -.61),
    ],
    elbowHints: [
      localPoint(root, yaw, -.045 + .08 * brace, hipHeight + .29, .43 - .36 * turn),
      localPoint(root, yaw, -.38, hipHeight + .22 - .07 * brace, -.78),
    ],
    handWeight: smooth(.35, 1, lower),
    handGroundWeight: [0, palmOnTurf],
    handGrip: [.27 + .10 * brace, lerp(.30, .06, palmOnTurf)],
    handSpread: [.10, .10 + .24 * palmOnTurf],
    wristPitch: [-.12, -.10],
    wristRoll: [.10, -.07],
    wristYaw: [-.08, .07],
    headPitch: .10 + recoil(elapsed - .09, .07, .28, .40),
    headYaw: lerp(.08, .23, turn), headRoll: .14 * turn,
    action: elapsed < -.31 ? '지지발을 디디고 체중 싣기' : elapsed < 0
      ? '골반을 낮추고 공 쪽으로 다리 뻗기' : elapsed < .15 ? '태클 접촉' : '측면으로 미끄러지며 감속',
  };
  const rearFlex=1.50-.25*retract,rearBend=1.82+.18*retract;
  releaseLeg(pose,1,ease(-.220,-.087,elapsed),rearFlex,.17,rearBend);
  let result = blendPose(run, pose, ease(-.64, -.30, elapsed));
  const clean = reaction === 'clean';
  const timing = clean ? { gather: .35, plant: .81, stand: 1.49 }
    : { gather: .49, plant: .99, stand: 1.76 };
  if (elapsed > timing.gather) {
    const settled = path(contactTime + .90);
    result = riseFromTurf(result, settled, yaw, t, elapsed, timing,
      { supportHand: 1, look: clean ? -.40 : .40, gesture: clean ? 'observe' : 'appeal' });
    const gather=ease(timing.gather,timing.plant,elapsed);
    const rearStep=1-ease(timing.plant+.14,timing.stand-.15,elapsed);
    releaseLeg(result,1,rearStep,lerp(rearFlex,-.15,gather),lerp(.17,.06,gather),lerp(rearBend,1.45,gather),
      .155*ease(timing.gather,timing.gather+.085,elapsed));
    if (clean && elapsed > timing.stand) {
      // Use the finished stance's ground root, independent of breathing or frame order.
      const start = localPoint(settled, yaw, .21, 0);
      const chasePath = time => {
        const u = Math.max(0, time - contactTime - timing.stand);
        const distance = 3.5 * (u - .25 * (1 - Math.exp(-u / .25)));
        const point = localPoint([start[0], start[2]], yaw, distance, 0, -distance * .22);
        return [point[0], point[2]];
      };
      const chase = sampleLocomotion(chasePath, t, { pace: 3.5, phase: .15 });
      const move = ease(timing.stand, timing.stand + .36, elapsed);
      result = blendPose(result, chase, move);
      result.action = '일어나 공을 따라가기';
    }
  }
  result.time = t;
  return fitGroundPalmClearance(result, [0, .042]);
}

// The scripted contact point remains fixed. The reaction follows the run's
// momentum: a recovery step for advantage, a brace for a forward fall, or
// hip/shoulder rotation followed by a tucked leg for a harder side fall.
export function sampleFoulReaction(origin, yaw, t, contactTime, type = 'careless') {
  const elapsed = t - contactTime;
  const runPath = time => {
    const point = localPoint(origin, yaw, -.20 + (time - contactTime) * 4.8, 0);
    return [point[0], point[2]];
  };
  const running = sampleLocomotion(runPath, t, { pace: 4.8, phase: .2 });

  const stride = ease(-.30, -.03, elapsed);
  const reaction = smooth(0, .084, elapsed);
  const serious = type === 'serious';
  const side = type === 'reckless' || serious;
  const clean = type === 'clean';
  const impactAt = serious ? .30 : clean ? .36 : .38;
  const fall = ease(0, impactAt, elapsed);
  const travel = u => -.20 + (u < 0 ? u * 4.8 : 1.15 * (1 - Math.exp(-u * 4.8 / 1.15)));
  const turn = serious ? -1 : 1;
  const braceHand = serious ? 1 : 0;
  const curl = ease(.42, .88, elapsed);
  const settle = ease(.88, 1.35, elapsed);
  const drift = side ? turn * .16 * ease(.055, .48, elapsed) : 0;
  const hip = localPoint(origin, yaw, travel(elapsed), 0, drift);
  const root = [hip[0], hip[2]];
  const near = vecLerp(
    localPoint(origin, yaw, -.20 + Math.min(0, elapsed) * 4.8 + .18, .10, .13),
    localPoint(origin, yaw, 0, .10, .13),
    stride,
  );
  const released = smooth(.035, .27, elapsed);
  const nearEnd = localPoint(root, yaw, -.24 + .17 * curl, .12 + .045 * curl, .13 + turn * .06 * curl);
  for (let i = 0; i < 3; i++) near[i] = lerp(near[i], nearEnd[i], released);
  near[1] += (clean ? .19 : .15) * Math.sin(fall * Math.PI);
  const far = localPoint(root, yaw, lerp(-.25, -.58 + (side ? .24 * curl : 0), fall),
    lerp(.14, .108 + (side ? .047 * curl : 0), fall), -.13 - .045 * curl * turn);
  const hipHeight = lerp(.88, side ? .265 : .30, fall) + recoil(elapsed - impactAt, .027, .20, .34);
  const pose = {
    hip: [root[0], hipHeight, root[1]], yaw,
    feet: [near, far], footPitch: [0, 0], footYaw: [0, 0],
    bootContact: [stride * (1 - ease(.01, .08, elapsed)), 0],
    looseBoot: [ease(.005,.19,elapsed),ease(-.045,.155,elapsed)],
    lean: .07 + reaction * (side ? .32 : .31) + fall * (side ? -.12 : .92),
    roll: side ? turn * (fall * (serious ? 1.38 : 1.24) + .19 * curl - .12 * settle) : .07 * fall,
    spinePitch: fall * (side?.29:.10) + recoil(elapsed - .028, .10, .22, .34) + recoil(elapsed - impactAt, .06, .22, .36),
    chestPitch: fall * (side?.06:-.03) + recoil(elapsed - .065, -.075, .24, .36),
    headPitch: -.18 * fall + recoil(elapsed - .095, .08, .26, .40) + (side ? .31 * curl : 0),
    headYaw: side ? .23 * turn * fall : 0,
    headRoll: recoil(elapsed - .08, side ? .08 : .04, .24, .36),
    armSwing: .2, elbow: .8,
    pain: reaction * (serious ? 1 : side ? .75 : clean ? .17 : .35),
    grip: 0, time: t, fall, reactionType: type,
    action: elapsed < 0 ? '접촉 전 디딤' : elapsed < .09 ? '접촉 / 즉각 균형 반응'
      : side ? '팔을 짚고 옆구리로 충격 분산' : '손과 굽힌 팔로 충격 받기',
  };
  pose.kneeHints = [0, 1].map(i => vecLerp(
    localPoint(root, yaw, .75, .72, i === 0 ? .13 : -.13),
    localPoint(root, yaw, .10 + .14 * curl, .32 + .045 * curl,
      (i === 0 ? 1 : -1)*(side?.42:.28)),
    smooth(.09, .36, elapsed),
  ));
  if(side){
    const release=serious?ease(.056,.24,elapsed):ease(.09,.31,elapsed);
    releaseLeg(pose,0,release,(serious?.466:.60)+.38*curl,serious?.09:-.12,1.10+.48*curl);
    releaseLeg(pose,1,release,(serious?.541:.63)+.33*curl,serious?.09:.15,serious?1.68:1.44);
  }else if(type!=='advantage'){
    pose.pelvisUnfold=.24*fall;
  }
  const palmSlide = ease(impactAt - .07, impactAt + .16, elapsed);
  const palmDrift = side ? turn * .16 * ease(.055, .48, impactAt + .045) : 0;
  const fixedPalm = localPoint(origin, yaw, travel(impactAt + .045), 0, palmDrift);
  const palmRoot = vecLerp(root, [fixedPalm[0], fixedPalm[2]], palmSlide);
  const nearGround = ease(impactAt - .14, impactAt - .025, elapsed);
  const farGround = ease(impactAt - .10, impactAt + .012, elapsed);
  pose.handTargets = [
    localPoint(palmRoot, yaw, .58, lerp(.17, .037, nearGround), .23),
    localPoint(palmRoot, yaw, .56, lerp(.19, .041, farGround), -.24),
  ];
  pose.handGroundWeight = [nearGround, farGround];
  if (side) {
    const sideOfFall = braceHand === 0 ? 1 : -1;
    pose.handTargets[braceHand] = localPoint(palmRoot, yaw, .30, lerp(.15, .040, nearGround), .34 * sideOfFall);
    pose.handTargets[1 - braceHand] = localPoint(root, yaw, .17, .30, -.13 * sideOfFall);
    pose.handGroundWeight = [0, 1].map(i => i === braceHand ? nearGround : 0);
  }
  pose.elbowHints = [localPoint(root, yaw, .32, .44, .40), localPoint(root, yaw, .32, .39, -.40)];
  pose.handWeight = smooth(.045, .27, elapsed);
  pose.handGrip = pose.handGroundWeight.map(w => lerp(.24, .06, w));
  pose.handSpread = pose.handGroundWeight.map(w => .10 + .26 * w);
  pose.wristPitch = [-.12, -.10];
  pose.wristYaw = [-.08, .08];
  let state = blendPose(running, pose, stride);
  if(side){
    const windup=ease(.015,.108,elapsed);
    const reach=[-1.05,braceHand===0?1.4:-1.4,0];
    state.armRotations[braceHand]=vecLerp(state.armRotations[braceHand],reach,windup);
  }

  if (type === 'advantage') {
    const recoveringPath = time => {
      const u = time - contactTime;
      const distance = u < 0 ? 4.8 * u : 4.4 * u + .12 * (1 - Math.exp(-u / .30));
      const point = localPoint(origin, yaw, -.20 + distance, 0);
      return [point[0], point[2]];
    };
    const recover = sampleLocomotion(recoveringPath, t, { pace: 4.4, phase: .2 });
    const balance = ease(0, .11, elapsed) * (1 - ease(.16, .53, elapsed));
    recover.hip[1] -= .087 * balance;
    recover.lean += .24 * balance;
    recover.roll += .13 * balance;
    recover.chestYaw -= .18 * balance;
    recover.armRotations = resolveArms(recover).arms.map((arm, i) => [
      arm[0] - .34 * balance, arm[1], arm[2] + (i === 0 ? -.41 : .40) * balance,
    ]);
    recover.action = elapsed < .53 ? '회복 발걸음으로 상체 균형 잡기' : '공격을 계속 이어가기';
    const runningArms = resolveArms(running);
    // Keep the contact step, but counterbalance with both arms without reaching for the turf.
    const stumble = {
      ...state,
      handTargets: undefined, elbowHints: undefined, handWeight: 0, handGroundWeight: [0, 0],
      armRotations: runningArms.arms.map((arm, i) => [
        arm[0] - .29 * balance, arm[1], arm[2] + (i === 0 ? -.35 : .35) * balance,
      ]),
      elbowAngles: runningArms.elbows,
      handGrip: [lerp(.38, .22, balance), lerp(.38, .24, balance)],
      handSpread: [.06 + .10 * balance, .06 + .10 * balance],
    };
    return fitKickReach(blendPose(stumble, recover, ease(0, .19, elapsed)));
  }

  if (side && elapsed > .42) {
    state.action = '옆으로 몸을 돌려 다리 보호';
    state.handGroundWeight = [0, 1].map(i => i === braceHand ? 1 - curl : 0);
    state.handTargets = [
      vecLerp(pose.handTargets[0], localPoint(root, yaw, -.07, .20, turn * .18), curl),
      vecLerp(pose.handTargets[1], localPoint(root, yaw, -.22, .18, turn * .04), curl),
    ];
    state.elbowHints = [
      vecLerp(pose.elbowHints[0], localPoint(root, yaw, .05, .36, serious?.13:turn*.43), curl),
      vecLerp(pose.elbowHints[1], localPoint(root, yaw, .15, .33, turn * .35), curl),
    ];
    state.handGrip = [0, 1].map(i => lerp(i === braceHand ? .06 : .24, i === braceHand ? .31 : .51, curl));
    state.handSpread = [0, 1].map(i => lerp(i === braceHand ? .36 : .10, .05, curl));
    state.wristPitch = [-.12 - .16 * curl, -.10 - .14 * curl];
    state.wristRoll = [.09 * curl, -.09 * curl];
  }
  if (!side) {
    const timing = clean ? { gather: .49, plant: .93, stand: 1.60 }
      : { gather: .68, plant: 1.16, stand: 1.93 };
    if (elapsed > timing.gather) {
      const settled = localPoint(origin, yaw, travel(.90), 0);
      state = riseFromTurf(state, [settled[0], settled[2]], yaw, t, elapsed, timing,
        { supportHand: 0, look: clean ? -.26 : .40, gesture: clean ? 'observe' : 'appeal', pain: clean ? 0 : .12 });
    }
  }
  const clearance = side ? (serious ? [0, .093] : [.087, 0]) : [.043, .031];
  return fitKickReach(fitGroundPalmClearance(state, clearance));
}

export function sampleBallFlightState(start,end,elapsed,duration,{loft=false,kind='pass',drag,magnus}={}) {
 return passTrack(start,end,duration,{loft,kind,drag,magnus}).at(elapsed);
}
export function sampleBallFlight(start,end,elapsed,duration,options) {
 return sampleBallFlightState(start,end,elapsed,duration,options).position;
}
const quatMultiply=(a,b)=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]];
export class BallRotationTrack {
 constructor(sample,{step=1/120,airSpin=10}={}){
   this.sample=sample;
   this.step=step;
   this.airSpin=airSpin;
   this.frames=[[0,0,0,1]];
   this.samples=[sample(0)];
 }
 increment(q,a,b,dt){
   const from=a.position||a,to=b.position||b;
   let axis,angle;
   if(a.spin||b.spin){
     const spin=a.spin&&b.spin?vecLerp(a.spin,b.spin,.5):(a.spin||b.spin),rate=Math.hypot(...spin);
     if(rate<1e-10)return q.slice();
     axis=spin.map(v=>v/rate);angle=rate*dt;
   }else{
     const dx=to[0]-from[0],dz=to[2]-from[2],distance=Math.hypot(dx,dz);
     if(distance<1e-10)return q.slice();
     axis=[dz/distance,0,-dx/distance];
     angle=(from[1]+to[1])*.5>BALL_RADIUS+.035?this.airSpin*dt:distance/BALL_RADIUS;
   }
   const sin=Math.sin(angle*.5);
   return quatMultiply([...axis.map(v=>v*sin),Math.cos(angle*.5)],q);
 }
 at(time){
   const t=Math.max(0,time),index=Math.floor(t/this.step);
   while(this.frames.length<=index){
     const n=this.frames.length,next=this.sample(n*this.step);
     this.frames.push(this.increment(this.frames[n-1],this.samples[n-1],next,this.step));
     this.samples.push(next);
   }
   const partial=t-index*this.step,q=this.frames[index];
   return partial<1e-10?q.slice():this.increment(q,this.samples[index],this.sample(t),partial);
 }
}
export function kickBallPosition(origin,yaw){return localPoint(origin,yaw,.66,BALL_RADIUS,.105);}
// Move the centre of mass through the kick; only the support boot plants.
// Quintic segments share velocity and acceleration at impact and recovery.
const curve3=(a,b,va,vb,elapsed,duration)=>a.map((v,i)=>hermite(v,b[i],va[i]*duration,vb[i]*duration,clamp(elapsed/duration)));
const pathVelocity=(path,t)=>{const a=path(t-.001),b=path(t+.001);return [(b[0]-a[0])/.002,0,(b[1]-a[1])/.002];};
export function fitKickReach(pose){
 return fitPelvisToFeet(pose,.859,.016);
}
// Profiles share an exact ball contact solve and use separate timing, striking
// surfaces and balance. Tuples for ankle targets are [forward, height, lateral].
const kickHands = {
  // Each row is grip, spread, pitch, yaw and roll, in the order of the two hands.
  receive: {load:[[.25,.33,-.08,-.10,.05],[.20,.42,-.05,.13,-.07]],through:[[.23,.32,.05,-.06,.05],[.34,.23,-.07,.06,-.09]]},
  inside: {load:[[.32,.27,-.08,-.07,.07],[.25,.40,-.12,.15,-.08]],through:[[.26,.36,.05,-.04,.10],[.39,.20,-.08,.07,-.11]]},
  loft: {load:[[.30,.39,-.13,-.11,.09],[.22,.49,-.07,.20,-.13]],through:[[.32,.32,.09,-.05,.09],[.40,.25,-.11,.06,-.10]]},
  drive: {load:[[.36,.34,-.09,-.12,.12],[.25,.52,-.13,.18,-.13]],through:[[.38,.24,.12,-.06,.12],[.48,.16,-.14,.08,-.13]]},
};
const kickProfiles = {
  inside: {
    backAt: -.155, back: [-.25, .30, .22],
    followAt: .105, follow: [.44, .285, .035], rejoinAt: .44,
    contactOffset: [.03648, -.05794, .16396], impactPitch: .06, impactYaw: -1.10, ballHeight: -.01311, ballSide: .04254,
    strikeSpeed: 6.4, riseSpeed: .35, sweepSpeed: .72,
    plantAt: -.054, plant: [.26, -.185], plantYaw: .20, releaseAt: .085,
    baseHeight: .945, load: .026, lift: .022, forwardShift: .062, sideLean: .057,
    lean: [.16, .18, .23], turn: [[-.16,.32],[-.07,.12],[-.16,.30]],
    arms: [[.13,-.42,-.49,-.28],[-.48,.25,.31,.40]], captureBlend: .43
  },
  drive: {
    backAt: -.20, back: [-.43, .49, .13],
    followAt: .155, follow: [.57, .52, .020], rejoinAt: .53,
    contactOffset: [-.00480, -.05322, .245], impactPitch: .22, impactYaw: .03, ballHeight: -.00814, ballSide: .00015,
    strikeSpeed: 9.6, riseSpeed: .62, sweepSpeed: .60,
    plantAt: -.064, plant: [.275, -.17], plantYaw: .12, releaseAt: .108,
    baseHeight: .94, load: .042, lift: .032, forwardShift: .076, sideLean: .08,
    lean: [.16, .24, .36], turn: [[-.23,.43],[-.15,.28],[-.30,.53]],
    arms: [[.30,-.56,-.66,-.35],[-.78,.44,.40,.57]], captureBlend: .89
  },
  loft: {
    backAt: -.225, back: [-.44, .43, .18],
    followAt: .165, follow: [.48, .60, .105], rejoinAt: .53,
    contactOffset: [-.00445, -.04636, .24003], impactPitch: .17, impactYaw: -.11, ballHeight: -.05626, ballSide: -.00005,
    strikeSpeed: 8.1, riseSpeed: 1.48, sweepSpeed: .35,
    plantAt: -.076, plant: [.21, -.20], plantYaw: .23, releaseAt: .126,
    baseHeight: .942, load: .036, lift: .027, forwardShift: .060, sideLean: .105,
    lean: [.00, -.06, .15], turn: [[-.26,.43],[-.13,.25],[-.26,.47]],
    arms: [[.26,-.44,-.69,-.43],[-.65,.35,.46,.59]], captureBlend: .57
  },
  receive: {
    backAt: -.135, back: [.39, .20, .14],
    followAt: .108, follow: [.21, .155, .17], rejoinAt: .35,
    contactOffset: [.03469, -.05796, .18480], impactPitch: -.04, impactYaw: -.91, ballHeight: -.01040, ballSide: .05556,
    strikeSpeed: -1.35, riseSpeed: -.20, sweepSpeed: -.34,
    plantAt: -.070, plant: [.22, -.205], plantYaw: .19, releaseAt: .082,
    baseHeight: .957, load: .045, lift: .016, forwardShift: .031, sideLean: .075,
    lean: [.10, .12, .22], turn: [[-.20,.18],[-.095,.10],[-.24,.29]],
    arms: [[.09,-.21,-.41,-.28],[-.30,.21,.37,.43]], captureBlend: 0
  }
};

export function sampleKick(origin, yaw, t, contactTime = 0, {
  power = 1, receiving = false, technique = 'drive', path = null, phase = .2,
  pace = receiving ? 2.6 : 3.6
} = {}) {
  const profile = receiving ? kickProfiles.receive : kickProfiles[technique] ?? kickProfiles.drive;
  const u = t - contactTime;
  const forward = [Math.sin(yaw), 0, Math.cos(yaw)];
  const lateral = [-Math.cos(yaw), 0, Math.sin(yaw)];
  const travel = path || linearPath(origin[0]-forward[0]*pace*contactTime,
    origin[1]-forward[2]*pace*contactTime, forward[0]*pace, forward[2]*pace);
  const root = travel(t);
  const base = sampleLocomotion(travel,t,{phase,pace});
  const period = sampleLocomotion(travel,contactTime,{phase,pace}).period || .7;

  // Match the approach stride to the plant, then lock that world-space anchor.
  // A fast approach leaves the support foot earlier to avoid dragging the shin.
  const plantAt = contactTime + profile.plantAt;
  const cycle = Math.round(plantAt/period + phase + .5);
  const matchedPhase = cycle - .5 - plantAt/period;
  const gait = at => sampleLocomotion(travel,at,{phase:matchedPhase,pace});
  const matched = gait(t);
  const gaitWeight = ease(-.80,-.42,u) * (1-ease(.34,.82,u));
  const run = blendPose(base,matched,gaitWeight);
  const weight = ease(-.46,-.28,u) * (1-ease(.22,.68,u));
  const release = profile.releaseAt - .042*ease(4.2,7,pace);
  const supportStart = -.30;
  const supportWeight = ease(supportStart,profile.plantAt,u) * (1-ease(release,release+.18,u));
  const ball = kickBallPosition(origin,yaw);
  const contactOffset = profile.contactOffset.slice();
  const contactDelta = rotate3(contactOffset,[profile.impactPitch,profile.impactYaw,0]);
  const radiusAhead = Math.sqrt(BALL_RADIUS**2-profile.ballHeight**2-profile.ballSide**2);
  const hit = localPoint(origin,yaw,.66-radiusAhead-contactDelta[2],
    BALL_RADIUS+profile.ballHeight-contactDelta[1],.105+profile.ballSide+contactDelta[0]);

  const backAt = profile.backAt, followAt = profile.followAt, rejoinAt = profile.rejoinAt;
  const effort = receiving ? 1 : clamp(power,.75,1.4);
  const back = localPoint(travel(contactTime+backAt),yaw,...profile.back);
  const end = localPoint(travel(contactTime+followAt),yaw,
    profile.follow[0],profile.follow[1]*(.70+.30*effort),profile.follow[2]);
  const strikeVelocity = forward.map((value, axis) => value*profile.strikeSpeed*effort
    + lateral[axis]*profile.sweepSpeed + (axis === 1 ? profile.riseSpeed*effort : 0));
  const backVelocity = pathVelocity(travel,contactTime+backAt);
  const followVelocity = pathVelocity(travel,contactTime+followAt);
  let foot;
  if (u < backAt) {
    const prepare = ease(-.44,backAt,u);
    foot = localPoint(root,yaw,lerp(-.08,profile.back[0],prepare),
      lerp(.40,profile.back[1],prepare),profile.back[2]);
  } else if (u < 0) {
    foot = curve3(back,hit,backVelocity,strikeVelocity,u-backAt,-backAt);
  } else if (u < followAt) {
    foot = curve3(hit,end,strikeVelocity,followVelocity,u,followAt);
  } else if (u < rejoinAt) {
    const rejoinTime = contactTime + rejoinAt;
    const after = gait(rejoinTime).feet[0];
    const a = gait(rejoinTime-.001).feet[0], b = gait(rejoinTime+.001).feet[0];
    foot = curve3(end,after,followVelocity,b.map((value,i)=>(value-a[i])/.002),
      u-followAt,rejoinAt-followAt);
  } else {
    foot = matched.feet[0];
  }

  const pose = {...run,feet:run.feet.map(v=>v.slice()),hip:run.hip.slice(),
    footPitch:run.footPitch.slice(),footYaw:run.footYaw.slice(),footRoll:run.footRoll.slice(),
    contactOffset,technique};
  pose.feet[0] = vecLerp(run.feet[0],foot,weight);
  const support = localPoint(origin,yaw,profile.plant[0],GROUND_FOOT,profile.plant[1]);
  const approachAt = contactTime + supportStart;
  const supportRelease = contactTime + release;
  const supportRejoin = supportRelease + .23;
  const supportGait = at => {
    const align = ease(-.80,-.42,at-contactTime) * (1-ease(.34,.82,at-contactTime));
    return vecLerp(sampleLocomotion(travel,at,{phase,pace}).feet[1],gait(at).feet[1],align);
  };
  if (t > approachAt && t < plantAt) {
    // Move with the pelvis on approach before reaching for the plant.
    const moveAt = lerp(approachAt,plantAt,.55);
    const moving = localPoint(travel(moveAt),yaw,receiving ? .255 : .31,.185,profile.plant[1]*.86);
    const moveVelocity = pathVelocity(travel,moveAt).map((v,axis)=>axis===1 ? -.75 : v);
    const a = supportGait(approachAt-.001), b = supportGait(approachAt+.001);
    const approachVelocity = b.map((v,axis)=>(v-a[axis])/.002);
    pose.feet[1] = t < moveAt
      ? curve3(supportGait(approachAt),moving,approachVelocity,moveVelocity,t-approachAt,moveAt-approachAt)
      : curve3(moving,support,moveVelocity,[0,0,0],t-moveAt,plantAt-moveAt);
  } else if (t >= plantAt && t <= supportRelease) {
    pose.feet[1] = support;
  } else if (t > supportRelease && t < supportRejoin) {
    // Release into the next stride without dragging the foot backwards first.
    const a = supportGait(supportRejoin-.001), b = supportGait(supportRejoin+.001);
    const rejoinVelocity = b.map((v,axis)=>(v-a[axis])/.002);
    pose.feet[1] = curve3(support,supportGait(supportRejoin),[0,0,0],rejoinVelocity,
      t-supportRelease,supportRejoin-supportRelease);
  }
  pose.bootContact = [ease(-.085,-.006,u)*(1-ease(.006,.086,u)),
    ease(profile.plantAt-.030,profile.plantAt,u)*(1-ease(release,release+.055,u))];

  const load = receiving ? ease(-.18,-.035,u)*(1-ease(.105,.26,u)) :
    ease(-.44,-.14,u)*(1-ease(-.06,.12,u));
  const push = ease(-.02,.10,u)*(1-ease(.14,.30,u));
  const drive = profile.forwardShift * ease(-.38,-.05,u)*(1-ease(.34,.91,u));
  const shift = localPoint(root,yaw,0,0,-.028*load-.047*supportWeight);
  const spring = recoil(u-.018,receiving ? .012 : .05,.22,.32);
  const preload = ease(-.33,-.15,u)*(1-ease(-.09,.02,u));
  pose.hip[0] = lerp(run.hip[0],shift[0],weight)+forward[0]*drive;
  pose.hip[2] = lerp(run.hip[2],shift[2],weight)+forward[2]*drive;
  pose.hip[1] = lerp(run.hip[1],profile.baseHeight-profile.load*load-(receiving ? .026 : .046)*preload+profile.lift*push+spring*.12,weight);
  pose.yaw = run.yaw + shortestAngle(run.yaw,yaw)*weight;

  const open = ease(backAt-.035,-.055,u)*(1-ease(.065,receiving ? .28 : .27,u));
  const pitchBack = receiving ? -.10 : technique === 'loft' ? -.24 : -.33;
  const pitchAfter = receiving ? -.09 : technique === 'loft' ? -.12 : technique === 'inside' ? .06 : .12;
  const pitch = lerp(pitchBack,profile.impactPitch,ease(backAt,-.047,u))
    + pitchAfter*ease(.045,.25,u);
  pose.footPitch[0] = lerp(run.footPitch[0],pitch,weight*(1-ease(followAt,rejoinAt,u)));
  pose.footYaw[0] = lerp(run.footYaw[0],profile.impactYaw*open,weight);
  pose.footRoll[0] *= 1-weight;
  pose.footPitch[1] *= 1-supportWeight;
  pose.footRoll[1] *= 1-supportWeight;
  pose.footYaw[1] = lerp(run.footYaw[1],shortestAngle(pose.yaw,yaw+profile.plantYaw),supportWeight);

  // When contact is close to the turf, keep the solid boot's sole clear. The
  // strike targets use visible Rocketbox mesh surfaces and sit above this plane.
  const active = ease(-.32,-.18,u)*(1-ease(.21,.37,u));
  if (active > 0) {
    const sole = Math.min(...[[0,-.084,.119],[-.03,-.079,.192],[.015,-.066,.226],[0,-.071,-.068]].map(point=>
      rotate3(point,[pose.footPitch[0],pose.footYaw[0],pose.footRoll[0]])[1]));
    const floor = -sole+.003;
    const margin = pose.feet[0][1]-floor;
    if (margin < .009) {
      const lift = margin <= -.009 ? -margin : (.009-margin)**2/.036;
      pose.feet[0][1] += lift*active;
    }
  }

  if (technique === 'loft' && !receiving) {
    pose.feet[0][1] += .012 * ease(-.135,-.080,u) * (1-ease(-.040,-.011,u));
  }
  const lean = lerp(profile.lean[0],profile.lean[1],ease(backAt,0,u))
    + (profile.lean[2]-profile.lean[1])*ease(0,followAt,u);
  const strength = receiving ? .48 : technique === 'inside' ? .66 : technique === 'loft' ? .92 : 1.18;
  const windupLoad = ease(-.42,backAt,u) * (1-ease(backAt+.024,-.014,u));
  const hipDrive = ease(-.055,.091,u) * (1-ease(.17,.39,u));
  const spineDrive = ease(-.037,.132,u) * (1-ease(.19,.49,u));
  const chestDrive = ease(.016,.188,u) * (1-ease(.24,.57,u));
  const chestLift = ease(-.24,-.126,u) * (1-ease(-.079,-.027,u));
  const absorb = receiving ? ease(-.016,.078,u) * (1-ease(.107,.255,u)) : 0;
  pose.lean = lerp(run.lean,lean + .020*strength*hipDrive,weight);
  pose.roll = lerp(run.roll,-profile.sideLean*supportWeight + .025*push
    - .018*strength*hipDrive,weight);
  const wind = ease(-.46,backAt,u);
  const releaseTimes = [[-.16,.055],[-.12,.095],[-.085,.14]];
  for (const [i, field] of ['pelvisYaw','spineYaw','chestYaw'].entries()) {
    const [windAngle,releaseAngle] = profile.turn[i];
    const [start,end] = releaseTimes[i];
    pose[field] = lerp(run[field],(windAngle*wind+releaseAngle*ease(start,end,u))*effort,weight);
  }
  pose.spinePitch = lerp(run.spinePitch || 0,
    -(receiving ? .035 : .065)*load + spring + strength*(-.056*windupLoad + .068*spineDrive)
    + .065*absorb,weight);
  pose.chestPitch = lerp(run.chestPitch || 0,
    -.023*load + recoil(u-.055,-.048,.25,.34)
    + strength*(-.051*chestLift + (technique === 'loft' && !receiving ? .040 : .112)*chestDrive)
    + .063*absorb,weight);

  // Side-foot contact opens the knee and hip as well as the shoe. Blend from
  // the current sagittal knee pole so the run and the kick use the same rig.
  const sideFoot = receiving || technique === 'inside';
  const guide = ease(-.36,-.15,u)*(1-ease(.13,.43,u));
  // Guide the thigh ahead of the boot so the inside edge can meet the ball
  // without the knee collapsing away from the target.
  const openLeg = sideFoot ? ease(backAt-.065,-.065,u)*(1-ease(.10,.30,u)) : 0;
  pose.kneeHints = [0,1].map(i=>{
    const sagittal = rotate3(rotate3([(i===0?-1:1)*HIP_SIDE,HIP_DROP,.8],
      [run.lean,run.pelvisYaw,run.roll]),[0,run.yaw,0]);
    const from = run.kneeHints?.[i] || add3(run.hip,sagittal);
    const to = i===0
      ? localPoint(root,yaw,lerp(.75,1.07,openLeg),lerp(.62,.76,openLeg),lerp(.18,receiving ? .17 : -.04,openLeg))
      : localPoint(root,yaw,.82,.62,-.22);
    return vecLerp(from,to,guide*weight);
  });

  const arm = resolveArms(run);
  const sweep = ease(-.09,followAt+.05,u);
  const armCatch = recoil(u-.085,.095,.25,.37);
  const reference = sampleKickReference(u);
  const sourceWeight = reference.weights.blend*weight*profile.captureBlend;
  pose.armRotations = profile.arms.map(([back,through,wide,narrow],i)=>{
    const target = [lerp(back,through,sweep)+(i===0?armCatch:-armCatch),0,lerp(wide,narrow,sweep)];
    const authored = vecLerp(arm.arms[i],target,weight);
    const measured = reference.arms[i];
    const result = vecLerp(authored,[measured[0]*1.25+.18,measured[1]*.45,measured[2]*.55],sourceWeight);
    result[2] += (i===0?-.044:.033)*supportWeight;
    return result;
  });
  pose.elbowAngles = arm.elbows.map((value,i)=>lerp(lerp(value,lerp(i?-.84:-.59,i?-1.11:-.93,sweep),weight),
    reference.elbows[i],sourceWeight));
  const hands = kickHands[receiving ? 'receive' : technique] ?? kickHands.drive;
  const balance = ease(-.35,-.13,u)*(1-ease(.19,.58,u));
  const handSweep = ease(-.085,followAt+.14,u);
  for(const [channel,index,defaultValue] of [
    ['handGrip',0,run.grip??.25],['handSpread',1,.21],['wristPitch',2,-.055],
    ['wristYaw',3,0],['wristRoll',4,0],
  ]) {
    pose[channel] = [0,1].map(i=>lerp(run[channel]?.[i]??defaultValue,
      lerp(hands.load[i][index],hands.through[i][index],handSweep),balance));
  }
  pose.spinePitch += reference.spine[0]*.09*sourceWeight;
  pose.chestPitch += reference.chest[0]*.085*sourceWeight;
  pose.spineRoll = lerp(pose.spineRoll || 0,reference.spine[2]*.24,sourceWeight*.29)
    + strength*(.033*windupLoad - .039*spineDrive)*weight;
  pose.chestRoll = lerp(pose.chestRoll || 0,reference.chest[2]*.24,sourceWeight*.29)
    + strength*(.059*windupLoad - .068*chestDrive)*weight;

  const watchBall = ease(-.36,-.065,u)*(1-ease(.075,.25,u));
  const glance = receiving ? .34*ease(-.47,-.30,u)*(1-ease(-.20,-.07,u)) : 0;
  const gaze = clamp(shortestAngle(yaw,yawFor(ball[0]-pose.hip[0],ball[2]-pose.hip[2])),-.48,.48);
  const pitchToBall = clamp(Math.atan2(pose.hip[1]+.57-BALL_RADIUS,
    Math.hypot(ball[0]-pose.hip[0],ball[2]-pose.hip[2]))*.48,.22,.64);
  pose.headPitch = lerp(run.headPitch,.025+pitchToBall*watchBall-pose.lean-pose.spinePitch-pose.chestPitch,weight);
  pose.headYaw = lerp(run.headYaw,gaze*watchBall-glance-pose.pelvisYaw-pose.spineYaw-pose.chestYaw,weight);
  pose.kickWeight = weight;
  pose.animationSource = receiving ? 'First touch / contact IK' : 'CMU 10_03 soccer kick + contact IK';
  pose.action = weight<.02 ? run.action : receiving ? '공 받기 · 인사이드 쿠션'
    : u<backAt ? '달리며 킥 준비' : u<0 ? '지지 발 디딤 / 타격' : u<followAt ? '후속 스윙' : '다음 보폭';

  fitPelvisToFeet(pose,.872,lerp(.018,.034,weight));
  return {pose,ball,contactTime,contactOffset};
}
function dribbleHeading(path, time) {
  const a=path(time-.04), b=path(time+.04);
  const dx=b[0]-a[0], dz=b[1]-a[1], speed=Math.hypot(dx,dz)/.08;
  if(speed>=.35)return {yaw:yawFor(dx,dz),speed};
  const past=path(time-.35), future=path(time+.35);
  const idle=path.idleYaw?.(time)??yawFor(future[0]-past[0],future[1]-past[1]);
  return {yaw:idle+shortestAngle(idle,yawFor(dx,dz))*ease(.02,.35,speed),speed};
}

function dribbleContact(path, time, foot, anchor) {
  const {yaw,speed}=dribbleHeading(path,time);
  const turn=shortestAngle(dribbleHeading(path,time-.14).yaw,dribbleHeading(path,time+.14).yaw);
  const cut=ease(.10,.56,Math.abs(turn)), side=foot===0?1:-1;
  const lead=.62-.10*cut+.09*ease(4.5,6.8,speed);
  const ball=anchor??localPoint(path(time),yaw,lead,BALL_RADIUS,side*(.105+.045*cut));
  return {time,foot,ball,yaw,face:yaw+clamp(turn*.44,-.25,.25)-side*.085,side,cut};
}

export function sampleDribble(path,t,{
  pace=2.8,phase=0,interval=.64,touchOffset=0,firstBall,lastTouch,ballOnly=false,adaptive=false
}={}) {
  // When another kick is due, it becomes the last contact of this carry.
  // Leave time for the support step by removing an otherwise crowded tap.
  const clock=(t-touchOffset)/interval;
  const lastCycle=lastTouch?Math.max(0,Math.floor((lastTouch.at-touchOffset-.28)/interval)):Infinity;
  const cycle=Math.min(lastCycle,Math.floor(clock+1e-9));
  const foot=((cycle%2)+2)%2, time=touchOffset+cycle*interval;
  const contact=dribbleContact(path,time,foot,cycle===0?firstBall:null);
  const finalLeg=cycle===lastCycle;
  const next=finalLeg
    ? {time:lastTouch.at,ball:lastTouch.ball,yaw:dribbleHeading(path,lastTouch.at).yaw}
    : dribbleContact(path,time+interval,1-foot,cycle===-1?firstBall:null);
  const ballMotion=passTrack(contact.ball,next.ball,next.time-time,{kind:'dribble'}).at(t-time);
  const result={ball:ballMotion.position,ballSpin:ballMotion.spin,ballVelocity:ballMotion.velocity,touchTime:time,activeFoot:foot};
  if(ballOnly)return result;

  const pose=sampleLocomotion(path,t,{pace,phase,adaptive});
  pose.footRoll??=[0,0];
  let focus=0, counterBalance=0;
  for(const touch of finalLeg?[contact]:[contact,next]) {
    const offset=t-touch.time;
    const weight=offset<0?ease(-.175,0,offset):1-ease(.012,.180,offset);
    if(weight<=0)continue;
    const step=touch.foot;
    const opening=shortestAngle(pose.yaw,touch.face);
    const pitch=.055, roll=.075*touch.side;
    const toe=rotate3(rotate3([0,0,BOOT_TOE],[pitch,opening,roll]),[0,pose.yaw,0]);
    // The boot continues through contact. Both sides of the touch share velocity.
    const push=.16*Math.tanh(offset/.072);
    const lift=offset<0?.07*ease(0,.175,-offset):.055*ease(.025,.158,offset);
    const target=[
      touch.ball[0]+Math.sin(touch.face)*(push-BALL_RADIUS)-toe[0],
      touch.ball[1]+lift-toe[1],
      touch.ball[2]+Math.cos(touch.face)*(push-BALL_RADIUS)-toe[2]
    ];
    pose.feet[step]=vecLerp(pose.feet[step],target,weight);
    pose.footYaw[step]+=shortestAngle(pose.footYaw[step],opening)*weight;
    pose.footPitch[step]=lerp(pose.footPitch[step],pitch,weight);
    pose.footRoll[step]=lerp(pose.footRoll[step],roll,weight);
    const transfer=weight*(.55+.45*touch.cut);
    pose.hip[1]-=.026*transfer;
    pose.roll+=.052*touch.side*transfer;
    pose.chestRoll=(pose.chestRoll||0)-.064*touch.side*transfer;
    counterBalance+=touch.side*transfer;
    focus=Math.max(focus,weight);
  }
  // Track a point on the route continuously even as ownership of the touch changes.
  const shoulderLead = .062 * Math.tanh(shortestAngle(pose.yaw,dribbleHeading(path,t+.22).yaw)*2);
  const overBall = .095 * focus;
  pose.spinePitch = (pose.spinePitch||0)+.44*overBall;
  pose.chestPitch = (pose.chestPitch||0)+.56*overBall;
  pose.spineYaw = (pose.spineYaw||0)+.34*shoulderLead;
  pose.chestYaw = (pose.chestYaw||0)+.66*shoulderLead-.042*counterBalance;
  pose.headPitch=(pose.headPitch||0)+.12*focus-.57*overBall;
  const lookAhead=dribbleHeading(path,t+.28).yaw;
  pose.headYaw=(pose.headYaw||0)+.34*Math.tanh(shortestAngle(pose.yaw,lookAhead)*1.26)-.66*shoulderLead;
  for(let i=0;i<2;i++){
    const side=i===0?1:-1;
    const reach=Math.max(0,-side*counterBalance);
    pose.armRotations[i][2]-=side*.125*reach;
    pose.wristYaw[i]+=side*.19*reach;
    pose.wristRoll[i]-=side*.085*reach;
    pose.handGrip[i]=Math.max(.08,pose.handGrip[i]-.12*reach);
    pose.handSpread[i]+=.11*reach;
  }
  pose.action=contact.cut>.24?'방향을 틀며 드리블':'드리블';
  fitKickReach(pose);
  return {...result,pose};
}
export function sampleOpenPlay(t,team='home',{ballOnly=false}={}){
 const d=team==='home'?1:-1,ids=[7,10,11,9],places=[[-12,7],[1,-5],[16,10],[25,-8]],cell=3.3,total=cell*4,mod=n=>((n%4)+4)%4;
 // Every athlete keeps one continuous route, including role changes between passes.
 const paths=places.map((point,j)=>{const next=places[(j+1)%4],yaw=yawFor((next[0]-point[0])*d,next[1]-point[1]);return tt=>{const a=(tt-(j*cell+.8))*Math.PI*2/(total*.5),p=localPoint([point[0]*d,point[1]],yaw,Math.sin(a)*5.2,0,(Math.cos(a)-1)*1.1);return [p[0],p[2]];};});
 const leg=n=>{
   const j=mod(n),k=(j+1)%4,kickAt=n*cell+.8,origin=paths[j](kickAt),loft=j===1||j===3,duration=loft?1.55:Math.hypot(places[k][0]-places[j][0],places[k][1]-places[j][1])/15,arrival=kickAt+duration,receiveOrigin=paths[k](arrival),v=pathVelocity(paths[k],arrival),receiveYaw=yawFor(v[0],v[2]),target=kickBallPosition(receiveOrigin,receiveYaw),yaw=yawFor(target[0]-origin[0],target[2]-origin[1]);
   return {j,k,kickAt,origin,loft,duration,arrival,receiveOrigin,receiveYaw,target,yaw,start:kickBallPosition(origin,yaw)};
 };
 const actors=new Map();
 for(let j=0;j<4&&!ballOnly;j++){
   const offset=j*cell+.8,n=j+4*Math.round((t-offset)/total),out=leg(n),incoming=leg(n-1),phase=j*.17;
   const carry=sampleDribble(paths[j],t,{pace:4,phase,touchOffset:incoming.arrival,firstBall:incoming.target,lastTouch:{at:out.kickAt,ball:out.start}}),carryWeight=smooth(incoming.arrival+.16,incoming.arrival+.48,t)*(1-smooth(out.kickAt-.62,out.kickAt-.46,t));let state=blendPose(sampleLocomotion(paths[j],t,{pace:4,phase}),carry.pose,carryWeight);
   if(t>out.kickAt-.80&&t<out.kickAt+.82)state=blendPose(state,sampleKick(out.origin,out.yaw,t,out.kickAt,{path:paths[j],pace:4,phase,technique:out.loft?'loft':'inside'}).pose,ease(out.kickAt-.80,out.kickAt-.60,t));
   else if(t>incoming.arrival-.80&&t<incoming.arrival+.82)state=blendPose(state,blendPose(sampleKick(incoming.receiveOrigin,incoming.receiveYaw,t,incoming.arrival,{receiving:true,path:paths[j],pace:4,phase}).pose,carry.pose,carryWeight),ease(incoming.arrival-.80,incoming.arrival-.60,t));
   fitKickReach(state);actors.set(ids[j],state);
 }
 const flightIndex=Math.floor((t-.8)/cell+1e-10),flight=leg(flightIndex);let ball;
 let ballSpin;
 if(t<flight.arrival){const state=sampleBallFlightState(flight.start,flight.target,t-flight.kickAt,flight.duration,{loft:flight.loft});ball=state.position;ballSpin=state.spin;}
 else{
   const next=leg(flightIndex+1);
   const carry=sampleDribble(paths[flight.k],t,{
     touchOffset:flight.arrival,firstBall:flight.target,lastTouch:{at:next.kickAt,ball:next.start},ballOnly:true
   });
   ball=carry.ball;ballSpin=carry.ballSpin;
 }
 return {actors,ball,ballSpin,sender:ids[flight.j],receiver:ids[flight.k],action:t<flight.arrival?(flight.loft?'로빙 패스':'빠른 패스'):'달리며 볼 컨트롤'};
}
function integratedEase(time, start, end) {
  if(time<=start)return 0;
  if(time>=end)return time-(start+end)/2;
  const q=(time-start)/(end-start);
  return (end-start)*q**3*(1-.5*q);
}
const cutRoute=time=>[
  -6+2.05*time+2.4*integratedEase(time,.04,.80)-1.82*integratedEase(time,1.07,1.48)
    +1.22*integratedEase(time,1.86,2.44)-2.12*integratedEase(time,2.94,3.7),
  2.65*(integratedEase(time,1.10,1.61)-integratedEase(time,2.23,2.87))
];
const RECEIVE_AT=1.4;
const receiveRoute=linearPath(-2.8*RECEIVE_AT,0,2.8,0);
function receiveIntoStride(path,yaw,t,arrival,pace,ballOnly){
  const origin=path(arrival),mark=kickBallPosition(origin,yaw);
  const carry=sampleDribble(path,t,{pace,touchOffset:arrival,firstBall:mark,ballOnly});
  if(ballOnly)return {mark,ball:carry.ball,ballSpin:carry.ballSpin};
  const receive=sampleKick(origin,yaw,t,arrival,{receiving:true,path,pace});
  return {
    pose:blendPose(receive.pose,carry.pose,ease(arrival+.10,arrival+.45,t)),
    mark,
    ball:carry.ball,
    ballSpin:carry.ballSpin,
  };
}
export function sampleMotionStudio(t,type='run',variant='careless',{ballOnly=false}={}){
 if(type==='model'){const pose=sampleIdle([0,0],Math.PI/2-t*.8,t);pose.headPitch=0;return {pose,ball:[0,BALL_RADIUS,0],action:'모델 보기 · 전신 / 재질 / 얼굴'};}
 if(type==='reaction'){
   const contactTime=1.4,clean=variant==='clean',early=clean?-.32:0;
   const height=variant==='serious'?.58:variant==='reckless'?.33:.11;
   const pitch=variant==='serious'?-1.05:variant==='reckless'?-.35:0;
   const pose=sampleFoulReaction([0,0],Math.PI/2,t,contactTime,variant);
   const receiver=sampleSlideTackle([clean?.425:0,height,clean?-.22:.13],Math.PI/2,t,contactTime+early,{pitch,reaction:variant});
   const elapsed=t-contactTime-early,start=[.54,BALL_RADIUS,-.22];
   const velocity=clean?[7.6,2.4,-4.4]:[3.6,0,-.35];
   const spin=clean?[-8,9,-14]:[velocity[2]/BALL_RADIUS,0,-velocity[0]/BALL_RADIUS];
   const ball=looseBallTrack(start,velocity,{spin}).at(elapsed);
   return {pose,receiver,ball:ball.position,ballSpin:elapsed>=0?ball.spin:undefined,action:pose.action+' / '+receiver.action,contactTime};
 }
 if(type==='tackle'){
   const contactTime=1.4,pose=sampleSlideTackle([0,BALL_RADIUS,0],Math.PI/2,t,contactTime);
   const start=[BALL_RADIUS,BALL_RADIUS,0];
   const impact=looseBallTrack(start,[7.6,.74,-4.4],{spin:[-5,9,-12]}).at(t-contactTime);
   return {pose,ball:impact.position,ballSpin:t>=contactTime?impact.spin:undefined,
     action:'슬라이딩 태클 · '+pose.action,contactTime};
 }
 if(type==='turn'||type==='dribble'){
   const carry=type==='dribble'?sampleDribble(cutRoute,t,{pace:4.6,adaptive:true}):null;
   const pose=carry?.pose||sampleLocomotion(cutRoute,t,{pace:4.6,adaptive:true});
   const action=carry?pose.action:'감속 · 디딤 · 방향 전환';
   return {pose,ball:carry?.ball||[0,BALL_RADIUS,0],ballSpin:carry?.ballSpin,action};
 }
 if(['walk','run','sprint'].includes(type)){
   const speed={walk:1.35,run:4.8,sprint:7.2}[type],path=linearPath(-speed*2,0,speed,0);
   const pose=sampleLocomotion(path,t,{pace:speed});
   return {pose,ball:[0,BALL_RADIUS,0],action:pose.action+' · '+speed.toFixed(1)+' m/s'};
 }
 if(type==='receive'){
   const yaw=.76,{pose,mark,ball,ballSpin}=receiveIntoStride(receiveRoute,yaw,t,RECEIVE_AT,2.8,ballOnly);
   const from=[mark[0]+4.6*Math.sin(yaw),BALL_RADIUS,mark[2]+4.6*Math.cos(yaw)];
   const arrival=passTrack(from,mark,.82).at(t-RECEIVE_AT+.82);
   return {pose,ball:t<RECEIVE_AT?arrival.position:ball,ballSpin:t<RECEIVE_AT?arrival.spin:ballSpin,
     action:t<RECEIVE_AT?'공을 보며 몸 열기':t<RECEIVE_AT+.22?'첫 터치 · 공을 진행 방향으로':'드리블',contactTime:RECEIVE_AT};
 }
 const loft=type==='lob',shot=type==='shot',duration=loft?1.75:shot?1.1:.88,contactTime=1.4,yaw=-1.30;
 const kickMark=kickBallPosition([0,0],Math.PI/2);
 const kick=ballOnly?null:sampleKick([0,0],Math.PI/2,t,contactTime,{power:shot?1.3:1,technique:shot?'drive':loft?'loft':'inside'});
 const approachZ=1.28*integratedEase(0,-.08,.46);
 const landing=shot?[25,BALL_RADIUS,.1]:loft?[21,BALL_RADIUS,.18]:kickBallPosition([16,approachZ],yaw);
 const track=passTrack(kickMark,landing,duration,{loft:loft||shot,kind:shot?'shot':'pass'});
 const flight=track.at(t-contactTime);
 const flightAction=flight.bounces>0
   ?(flight.position[1]<=BALL_RADIUS+1e-5&&Math.abs(flight.velocity[1])<.001?'잔디 위로 구르는 중':'잔디에 튀는 중')
   :shot?'슈팅 비행':'공 이동';
 if(shot){
   return {pose:kick?.pose,ball:flight.position,ballSpin:t<contactTime?[0,0,0]:flight.spin,
     ballBounces:flight.bounces,action:'강한 슈팅 · '+(t<contactTime?kick?.pose.action:flightAction),
     contactTime,arrival:contactTime+duration};
 }
 // Leave the high pass free through its bounces; the receiver meets it after it settles.
 const receiveAt=loft?3.42:duration,arrival=contactTime+receiveAt;
 const mark=track.at(receiveAt).position,footOffset=kickBallPosition([0,0],yaw);
 const path=time=>{
   const elapsed=time-arrival;
   return [mark[0]-footOffset[0]-2.58*elapsed,
     mark[2]-footOffset[2]+.72*elapsed+1.28*integratedEase(elapsed,-.08,.46)-approachZ];
 };
 const receive=receiveIntoStride(path,yaw,t,arrival,2.85,ballOnly);
 const ball=t<arrival?flight.position:receive.ball;
 const ballSpin=t<contactTime?[0,0,0]:t<arrival?flight.spin:receive.ballSpin;
 const action=t<contactTime?kick?.pose.action:t<arrival?flightAction:t<arrival+.28?'퍼스트 터치':'받은 뒤 드리블';
 return {pose:kick?.pose,receiver:receive.pose,ball,ballSpin,
   ballBounces:flight.bounces,action:(loft?'로빙 패스':'빠른 패스')+' · '+action,contactTime,arrival};
}
// One continuous route per player, including the switch from receiving to
// carrying to passing. These routes stay on the pitch for arbitrarily long play.
function passingSequence(mark,d,kickAt,{cross=false,ids=[10,7,11,9]}={}){
 const cell=3.6,total=cell*4,side=mark[2]>0?-1:1;
 const places=[[mark[0]-.66*d,mark[2]-.105*d],[mark[0]+(cross?19:8)*d,mark[2]+side*(cross?10:4)],[mark[0]+14*d,mark[2]-side*7],[mark[0]+4*d,mark[2]-side*10]].map(p=>[clamp(p[0],-43,43),clamp(p[1],-24,24)]);
 const orbit=(j,tt)=>{const a=(tt-kickAt-j*cell)*Math.PI*2/total;return [places[j][0]+d*Math.sin(a)*2.1,places[j][1]+Math.cos(a)*1.2];};
 const duration=n=>n===0&&cross?1.65:clamp(Math.hypot(places[(n+1)%4][0]-places[n%4][0],places[(n+1)%4][1]-places[n%4][1])/14,.58,1.8);
 const arrival=kickAt+duration(0),receiveRoot=orbit(1,arrival),v=pathVelocity(tt=>orbit(1,tt),arrival),receiveYaw=yawFor(v[0],v[2]),target=kickBallPosition(receiveRoot,receiveYaw),yaw=yawFor(target[0]-mark[0],target[2]-mark[2]),offset=localPoint([0,0],yaw,.66,0,.105),origin=[mark[0]-offset[0],mark[2]-offset[2]];
 const paths=places.map((_,j)=>tt=>{
   if(j)return orbit(j,tt);
   const u=tt-kickAt,q0=clamp((u+1.1)/.3),approach=u<-.8?-.95+.3*(q0**3-.5*q0**4):u>.8?.8+.5*(1-Math.exp(-(u-.8)/.5)):u,root=[origin[0]+Math.sin(yaw)*approach*3.6,origin[1]+Math.cos(yaw)*approach*3.6];
   const q=ease(kickAt+.8,kickAt+2.4,tt);return vecLerp(root,orbit(0,tt),q);
 });
 const leg=n=>{
   const j=n%4,k=(j+1)%4,at=kickAt+n*cell,flight=duration(n),arrive=at+flight,receiveOrigin=paths[k](arrive),velocity=pathVelocity(paths[k],arrive),receiveYaw=yawFor(velocity[0],velocity[2]),end=kickBallPosition(receiveOrigin,receiveYaw),root=paths[j](at),face=n===0?yaw:yawFor(end[0]-root[0],end[2]-root[1]);
   return {j,k,at,flight,arrive,receiveOrigin,receiveYaw,end,root,face,start:n===0?mark:kickBallPosition(root,face),loft:n===0?cross:j===2};
 };
 return (t,{ballOnly=false}={})=>{
   const n=Math.max(0,Math.floor((t-kickAt)/cell+1e-10)),flight=leg(n),actors=new Map();
   for(let j=0;j<4&&!ballOnly;j++){
     const cycle=Math.max(0,Math.round((t-kickAt-j*cell)/total)),out=leg(j+cycle*4),incoming=j+cycle*4>0?leg(j+cycle*4-1):null,phase=j*.17,path=paths[j];
     const run=sampleLocomotion(path,t,{pace:3.6,phase});let state=blendPose(sampleIdle(path(t),j===0?yaw:run.yaw,t),run,smooth(.04,1.0,run.speed||0));
     if(incoming){const carry=sampleDribble(path,t,{pace:3.6,phase,touchOffset:incoming.arrive,firstBall:incoming.end,lastTouch:{at:out.at,ball:out.start}}),weight=smooth(incoming.arrive+.16,incoming.arrive+.48,t)*(1-smooth(out.at-.62,out.at-.46,t));state=blendPose(state,carry.pose,weight);
       if(t>incoming.arrive-.80&&t<incoming.arrive+.82)state=blendPose(state,blendPose(sampleKick(incoming.receiveOrigin,incoming.receiveYaw,t,incoming.arrive,{receiving:true,path,phase}).pose,carry.pose,weight),ease(incoming.arrive-.80,incoming.arrive-.60,t));
     }
     if(t>out.at-.80&&t<out.at+.82)state=blendPose(state,sampleKick(out.root,out.face,t,out.at,{path,phase,technique:out.loft?'loft':'inside'}).pose,ease(out.at-.80,out.at-.60,t));
     actors.set(ids[j],state);
   }
   let ball,ballSpin;
   if(t<kickAt)ball=mark.slice();
   else if(t<flight.arrive){const state=sampleBallFlightState(flight.start,flight.end,t-flight.at,flight.flight,{loft:flight.loft});ball=state.position;ballSpin=state.spin;}
   else{
     const next=leg(n+1);
     const carry=sampleDribble(paths[flight.k],t,{
       touchOffset:flight.arrive,firstBall:flight.end,lastTouch:{at:next.at,ball:next.start},ballOnly:true
     });
     ball=carry.ball;ballSpin=carry.ballSpin;
   }
   return {ball,ballSpin,actors,passAt:flight.at,passSound:flight.loft?'chip':'kick',arrival:flight.arrive,initialArrival:arrival,sender:ids[flight.j],receiver:ids[flight.k],phase:t<kickAt?'setup':t<flight.arrive?'pass':'carry',action:t<kickAt?'프리킥 준비':t<flight.arrive?(flight.loft?'크로스 / 로빙 패스':'짧은 패스'):'볼 컨트롤 · 공격 연결'};
 };
}
const restartSequences=new WeakMap();
function restartSequence(record,start){
 const key=[start.x,start.z,start.dir,record.style,record.goal,record.decision.restart].join('|'),prior=restartSequences.get(record);
 if(prior?.key===key)return prior.sample;
 const restart=record.decision.restart,d=start.dir,team=record.decision.beneficiary,other=team==='home'?'away':'home',style=record.style||(['penalty','free','advantage','play'].includes(restart)?'shot':restart==='drop'?'drop':'short'),kickAt=['advantage','play'].includes(restart)?1.3:2.2;
 const mark=[start.x,BALL_RADIUS,start.z],origin=[start.x-.66*d,start.z-.105*d],yaw=d*Math.PI/2;
 const kickPath=tt=>{const u=tt-kickAt,q=clamp((u+1.1)/.3),s=u<-.8?-.95+.3*(q**3-.5*q**4):u>.8?.8+.6*(1-Math.exp(-(u-.8)/.6)):u;return [origin[0]+d*3.6*s,origin[1]];};
 const kickState=t=>{const kick=sampleKick(origin,yaw,t,kickAt,{power:1.1,technique:'drive',path:kickPath});return blendPose(sampleIdle(kickPath(t),yaw,t),kick.pose,smooth(.04,1,kick.pose.speed||0));};
 const end=[(record.goal?54:50)*d,record.goal?.26:.45,record.goal?1.7:-.9],duration=Math.max(.38,Math.hypot(end[0]-start.x,end[2]-start.z)/(restart==='penalty'?24:22)),saveAt=kickAt+duration;
 const shotTrack=passTrack(mark,end,duration,{loft:true,kind:'shot'}),arrival=shotTrack.at(duration);
 const afterContact=record.goal
   ? createBallTrack(end,arrival.velocity,{spin:arrival.spin,goalFrame:true,net:true})
   : createBallTrack(end,[-d*4.35,.91,-2.1],{spin:[-7,7,d*15],restitution:.46});
 const drop=looseBallTrack([start.x,1.25,start.z],[0,0,0],{restitution:.47});
 const passing=passingSequence(mark,d,kickAt,{cross:style==='cross'}),defence=passingSequence(afterContact.at(1.55).position,-d,saveAt+1.55,{ids:[4,7,11,9]}),kickoffAt=saveAt+4.1,kickoff=passingSequence([0,BALL_RADIUS,0],-d,kickoffAt),dropPath=linearPath(start.x-.62*d-3.4*d*1.92,start.z+.105*d,3.4*d,0),dropEnd=sampleDribble(dropPath,3,{pace:3.4}).ball,dropPass=passingSequence(dropEnd,d,3);
 const sample=(t,options={})=>{
   const base={kickAt,duration,q:clamp((t-kickAt)/duration),team,inPlay:t>=kickAt,canAdvance:t>=kickAt+7,fade:0};
   if(style==='short'||style==='cross')return {...base,...passing(t,options)};
   if(style==='drop'){
     if(t>=3)return {...base,...dropPass(t,options),inPlay:true};
     const elapsed=Math.max(0,t-.65),control=sampleDribble(dropPath,t,{pace:3.4}),carry=t>1.92?control:null,pose=blendPose(sampleLocomotion(dropPath,t,{pace:3.4}),control.pose,smooth(1.68,1.91,t)),future=dropPass(t,options).actors.get(10),weight=ease(2.25,3,t);
     const dropped=drop.at(elapsed),landed=dropped.bounces>0;
     return {...base,ball:carry?.ball||dropped.position,ballSpin:carry?.ballSpin??dropped.spin,actors:new Map([[10,future?blendPose(pose,future,weight):pose]]),phase:landed?'carry':'drop',inPlay:landed,action:landed?'볼 컨트롤 · 공격 연결':'드롭볼'};
   }
   if(record.goal&&t>=saveAt+2.6){const next=kickoff(t,options);return {...base,...next,team:other,kickoffAt,phase:t<kickoffAt?'kickoff':next.phase,inPlay:t>=kickoffAt,action:t<kickoffAt?'득점 후 상대 팀 킥오프':next.action,fade:1-ease(saveAt+2.6,saveAt+3.1,t),canAdvance:t>=kickoffAt+4};}
   const actors=options.ballOnly?new Map():new Map([[10,kickState(t)]]);
   if(!record.goal&&t>=saveAt+1.55){const next=defence(t,options);return {...base,...next,team:other,otherTeam:team,otherActors:actors,saveAt,saveTarget:end,phase:next.phase,action:next.action,inPlay:true};}
   const flight=t<kickAt?{position:mark}:t<=saveAt?shotTrack.at(t-kickAt):afterContact.at(t-saveAt);
   const extra=!record.goal?defence(t,options).actors:new Map();
   return {...base,ball:flight.position,ballSpin:flight.spin,actors,otherActors:extra,otherTeam:other,shot:true,saveAt,saveTarget:end,phase:t<kickAt?'setup':t<saveAt?'shot':record.goal?'goal':'rebound',inPlay:t>=kickAt&&!(record.goal&&t>=saveAt),action:t<kickAt?'슈팅 준비':t<saveAt?'슈팅':record.goal?'득점 · 상대 팀 킥오프 준비':'선방 · 세컨드 볼 경합',fade:record.goal?ease(saveAt+2.1,saveAt+2.6,t):0};
 };
 restartSequences.set(record,{key,sample});return sample;
}
export function sampleRestartBall(t,record,start,options={}){return restartSequence(record,start)(t,options);}
