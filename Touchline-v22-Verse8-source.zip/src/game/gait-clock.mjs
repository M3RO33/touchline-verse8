// Gait time is measured in accumulated strides. Curves are sampled from a
// fixed time grid so seeking or replaying a frame cannot change the step phase.
const SAMPLE_TIME = 1 / 12;
const profiles = new WeakMap();
const clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));
const lerp = (a, b, amount) => a + (b - a) * amount;
const ease = (a, b, value) => {
  const t = clamp((value - a) / (b - a), 0, 1);
  return t * t * t * (10 + t * (-15 + 6 * t));
};

export function gaitTiming(speed) {
  const pace = Math.max(.05, speed);
  const run = ease(1.8, 2.6, pace);
  const sprint = ease(4.9, 7.2, pace);
  const walkingPeriod = lerp(1.10, .84, clamp((pace - .7) / 1.35, 0, 1));
  const runningPeriod = lerp(.73, .55, clamp((pace - 2.05) / 5, 0, 1));
  const period = lerp(walkingPeriod, runningPeriod, run);
  const stance = lerp(.60, lerp(.28, .21, clamp((pace - 2.05) / 5, 0, 1)), run);
  return {pace, run, sprint, period, stance};
}

export function pathSpeed(path, time, halfWindow = .012) {
  const from = path(time - halfWindow), to = path(time + halfWindow);
  return Math.hypot(to[0] - from[0], to[1] - from[1]) / (2 * halfWindow);
}

export function cadenceProfile(path, preferredPace) {
  let byPace = profiles.get(path);
  if (!byPace) profiles.set(path, byPace = new Map());
  if (byPace.has(preferredPace)) return byPace.get(preferredPace);

  const maxPace = preferredPace == null ? 8.8 : Math.min(8.8, Math.max(preferredPace + .8, preferredPace * 1.3));
  const timingAt = time => gaitTiming(Math.min(maxPace, pathSpeed(path, time, .060)));
  const rateAt = index => {
    const timing = timingAt(index * SAMPLE_TIME);
    // Take smaller, slower steps as the athlete settles.
    return lerp(.56, 1 / timing.period, ease(.04, .8, timing.pace));
  };
  let first = 0, last = 0;
  const rows = new Map([[0, {phase: 0, rate: rateAt(0)}]]);
  function extend(index) {
    while (index < first) {
      const after = rows.get(first), rate = rateAt(--first);
      rows.set(first, {phase: after.phase - (after.rate + rate) * SAMPLE_TIME * .5, rate});
    }
    while (index > last) {
      const before = rows.get(last), rate = rateAt(++last);
      rows.set(last, {phase: before.phase + (before.rate + rate) * SAMPLE_TIME * .5, rate});
    }
  }

  function phaseAt(time) {
    const i = Math.floor(time / SAMPLE_TIME), fraction = time / SAMPLE_TIME - i;
    extend(i);
    extend(i + 1);
    const a = rows.get(i), b = rows.get(i + 1);
    return a.phase + SAMPLE_TIME * fraction * (a.rate + .5 * (b.rate - a.rate) * fraction);
  }

  function timeAt(phase) {
    while (phase < rows.get(first).phase) extend(first - 1);
    while (phase > rows.get(last).phase) extend(last + 1);
    let low = first, high = last;
    while (high - low > 1) {
      const mid = Math.floor((low + high) / 2);
      if (rows.get(mid).phase <= phase) low = mid;
      else high = mid;
    }
    if (low === high) return low * SAMPLE_TIME;
    const a = rows.get(low), b = rows.get(high);
    const distance = (phase - a.phase) / SAMPLE_TIME;
    // Invert the integral of the linearly interpolated cadence.
    const denominator = a.rate + Math.sqrt(Math.max(0, a.rate * a.rate + 2 * (b.rate - a.rate) * distance));
    return (low + clamp(2 * distance / denominator, 0, 1)) * SAMPLE_TIME;
  }

  const profile = {phaseAt, timeAt, timingAt};
  byPace.set(preferredPace, profile);
  return profile;
}

