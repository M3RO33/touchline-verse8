import {ATHLETE_RESOURCES} from './athlete-resources.mjs';
export const ATHLETE_TEXTURES = {
  body: ATHLETE_RESOURCES.body,
  head: ATHLETE_RESOURCES.head,
  bodyNormal: ATHLETE_RESOURCES.bodyNormal,
  headNormal: ATHLETE_RESOURCES.headNormal,
};
