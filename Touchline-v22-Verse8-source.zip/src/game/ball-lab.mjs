import {BALL_RADIUS,createBallTrack} from './ball-physics.mjs';
export const BALL_LAB_RELEASE=.60;
const demo={
  ground:{title:'지면 패스',start:[0,BALL_RADIUS,0],velocity:[8.1,0,.38],spin:[0,1,-38],sound:'kick'},
  driven:{title:'낮은 슛',start:[0,BALL_RADIUS,0],velocity:[19.5,3.45,.7],spin:[-2,18,-35],sound:'shot'},
  loft:{title:'로빙',start:[0,BALL_RADIUS,0],velocity:[14.6,8.35,1.7],spin:[-3,21,36],sound:'chip'},
  drop:{title:'드롭볼',start:[0,1.35,0],velocity:[0,0,0],spin:[0,0,0]},
};
for(const row of Object.values(demo))row.track=createBallTrack(row.start,row.velocity,{spin:row.spin});
export function sampleBallLab(t,kind='ground'){
  const row=demo[kind]??demo.ground;
  const state=t<BALL_LAB_RELEASE?{position:row.start,velocity:[0,0,0],spin:[0,0,0],bounces:0}:row.track.at(t-BALL_LAB_RELEASE);
  const height=Math.max(0,state.position[1]-BALL_RADIUS),speed=Math.hypot(...state.velocity);
  return {...state, height, speed, title:row.title, sound:row.sound};
}
