import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';

const root = path.resolve(import.meta.dirname, '..');
const gameRoot = path.resolve(process.env.TOUCHLINE_GAME_SOURCE ?? path.join(root, '../touchline'));
const source = path.join(gameRoot, 'dist');
const destination = path.join(root, 'src/game');
const checkOnly = process.argv.includes('--check');
const hash = content => createHash('sha256').update(content).digest('hex');
const read = file => fs.readFile(path.join(source, file), 'utf8');
const gamePackage = JSON.parse(await fs.readFile(path.join(gameRoot, 'package.json'), 'utf8'));
const provenance = {gameVersion: gamePackage.version, files: {}, assets: {}, licenses: []};
if (!/^\d+\.\d+\.\d+$/.test(provenance.gameVersion)) throw new Error('Invalid game package version.');

const modules = new Map();
for (const name of (await fs.readdir(source)).filter(name => /\.(js|mjs)$/.test(name)).sort()) {
  const original = await read(name);
  const content = original.replaceAll("from './vendor/three.module.js'", "from 'three'");
  modules.set(name, content);
  provenance.files[name] = hash(content);
}

const html = await read('index.html');
const body = html.match(/<body\b[^>]*>/)?.[0];
const markup = html.match(/<body\b[^>]*>([\s\S]*?)<script type="module" src="\.\/app\.js"><\/script>\s*<\/body>/)?.[1];
if (!body || !markup) throw new Error('Game markup not found.');
const css = await read('style.css');
if (/@import|fonts\.googleapis\.com|fonts\.gstatic\.com/.test(css)) {
  throw new Error('The game theme must be self-contained.');
}
const wrapperFile = path.join(root, 'index.html');
let wrapper = await fs.readFile(wrapperFile, 'utf8');
for (const pattern of [/<meta name="theme-color"[^>]*>/, /<meta name="description"[^>]*>/,
  /<title>[\s\S]*?<\/title>/, /<link rel="icon"[^>]*>/, /<body\b[^>]*>/]) {
  const canonicalTag = html.match(pattern)?.[0];
  if (canonicalTag) wrapper = wrapper.replace(pattern, () => canonicalTag);
}
if (!wrapper.includes(body)) throw new Error('Initial game body mode could not be copied to the wrapper.');

async function filesIn(directory, prefix = '') {
  const files = [];
  for (const entry of await fs.readdir(directory, {withFileTypes: true})) {
    const relative = path.posix.join(prefix, entry.name);
    if (entry.isDirectory()) files.push(...await filesIn(path.join(directory, entry.name), relative));
    else if (entry.isFile()) files.push(relative);
  }
  return files.sort();
}

const assets = new Map();
for (const name of await filesIn(path.join(source, 'assets'))) {
  const content = await fs.readFile(path.join(source, 'assets', name));
  assets.set(name, content);
  provenance.assets[name] = {bytes: content.length, sha256: hash(content)};
}
const licenses = new Map([
  ['LICENSE-three.txt', await read('vendor/LICENSE-three.txt')],
  ['ASSET-CREDITS.txt', await read('ASSET-CREDITS.txt')],
  ['SHIPPED-SOURCES.txt', await read('SHIPPED-SOURCES.txt')]
]);
for (const name of await filesIn(path.join(source, 'licenses'))) {
  licenses.set(name, await read('licenses/' + name));
}
provenance.licenses = [...licenses.keys()].sort();

function ownedFile(directory, name) {
  const file = path.resolve(directory, name);
  const relative = path.relative(directory, file);
  if (!relative || path.isAbsolute(relative) || relative === '..' || relative.startsWith('..' + path.sep)) {
    throw new Error('Generated file is outside the target directory: ' + name);
  }
  return file;
}

async function syncGenerated(directory, entries, previousNames) {
  for (const [name, content] of entries) {
    const file = ownedFile(directory, name);
    await fs.mkdir(path.dirname(file), {recursive: true});
    await fs.writeFile(file, content);
  }
  for (const name of previousNames) {
    if (!entries.has(name)) await fs.rm(ownedFile(directory, name), {force: true});
  }
}

if (!checkOnly) {
  const provenanceFile = path.join(root, 'SOURCE-PROVENANCE.json');
  let previous = {};
  try {
    previous = JSON.parse(await fs.readFile(provenanceFile, 'utf8'));
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  await syncGenerated(destination, modules, Object.keys(previous.files ?? {}));
  await syncGenerated(path.join(root, 'public/assets'), assets, Object.keys(previous.assets ?? {}));
  await syncGenerated(path.join(root, 'licenses'), licenses, previous.licenses ?? []);
  await fs.writeFile(wrapperFile, wrapper);
  await fs.writeFile(path.join(destination, 'markup.html'), markup);
  await fs.writeFile(path.join(destination, 'style.css'), css);
  await fs.writeFile(provenanceFile, JSON.stringify(provenance, null, 2) + '\n');
}
console.log('Verse8 ' + (checkOnly ? 'source validated' : 'source prepared') + ' for ' + provenance.gameVersion
  + ': ' + modules.size + ' modules, ' + assets.size + ' assets, ' + licenses.size + ' notices.');

